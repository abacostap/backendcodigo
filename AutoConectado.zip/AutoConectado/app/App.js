import React from 'react';
import { Alert, Animated, Easing, NetInfo, StatusBar, UIManager, View } from 'react-native';

import { StackNavigator } from 'react-navigation';
//mobx
import { Provider } from 'mobx-react';
//storage
import stores from './src/mobx';
import firebase from 'react-native-firebase';
import { IS_ANDROID } from './src/utils/framework';
import { KEYS, setSetting } from './src/utils/settings';
//pages
import homeScreen from './src/pages/home';
import loginScreen from './src/pages/login';
import splashScreen from './src/pages/splash';
import travelsScreen from './src/pages/travels';
import liveTravelScreen from './src/pages/liveTravel';
import travelDetailScreen from './src/pages/travelDetail';
import notificationScreen from './src/pages/notification';
import notificationsScreen from './src/pages/notifications';
import profileScreen from './src/pages/profile';

const transitionConfig = () => {
  return {
    transitionSpec: {
      duration: 750,
      easing: Easing.out(Easing.poly(4)),
      timing: Animated.timing,
      useNativeDriver: true
    },
    screenInterpolator: sceneProps => {
      const { layout, position, scene } = sceneProps;

      const thisSceneIndex = scene.index;
      const width = layout.initWidth;

      const translateX = position.interpolate({
        inputRange: [thisSceneIndex - 1, thisSceneIndex],
        outputRange: [width, 0]
      });

      return { transform: [{ translateX }] };
    }
  };
};

const RootStack = StackNavigator(
  {
    home: homeScreen,
    splash: splashScreen,
    travels: travelsScreen,
    login: loginScreen,
    liveTravel: liveTravelScreen,
    travelDetail: travelDetailScreen,
    notification: notificationScreen,
    notifications: notificationsScreen,
    profile: profileScreen
  },
  {
    initialRouteName: 'splash',
    transitionConfig,
    headerMode: 'none'
  }
);

// Enable LayoutAnimation on Android
if (UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

export default class App extends React.Component {
  constructor(props) {
    super(props);
    console.disableYellowBox = true;
  }

  componentDidMount() {
    //get the initial value for network connection (true or false)
    NetInfo.isConnected.fetch().then(isConnected => {
      console.log('connection', isConnected);
      stores.appStore.isConnected(isConnected);
    });

    //listenigg for connection changes
    NetInfo.isConnected.addEventListener('connectionChange', isConnected => {
      console.log('connectionChange', isConnected);
      stores.appStore.isConnected(isConnected);
    });

    this.getFCM();
    this.onTokenRefreshListener = firebase.messaging().onTokenRefresh(fcmToken => {
      // Process your token as required
      console.log(' onTokenRefreshListener fcmToken', fcmToken);
      // stores.appStore.setFcmToken(fcmToken)
    });
  }

  getFCM = async () => {
    const fcmToken = await firebase.messaging().getToken();
    if (fcmToken) {
      console.log('getToken fcmToken', fcmToken);
      //susbcribe to the users a topic to allow recive notification from mockserver
      firebase.messaging().subscribeToTopic('auto-conectado-all-users');
      //stores.appStore.setFcmToken(fcmToken)
      this.initFirebaseNotifications();
    } else {
      // user doesn't have a device token yet
    }
  };

  async initFirebaseNotifications() {
    const enabled = await firebase.messaging().hasPermission();
    if (enabled) {
      // user has permissions
      this.firebaseMessaging();
    } else {
      // user doesn't have permission
      this.firebaseMessagingRequestPersmission();
    }
  }

  /**
   * make a request to get the message permission
   * @returns {Promise.<void>}
   */
  async firebaseMessagingRequestPersmission() {
    try {
      await firebase.messaging().requestPermission();
      // User has authorised
      this.firebaseMessaging();
    } catch (error) {
      // User has rejected permissions
      this.firebaseMessagingRequestPersmission();
    }
  }

  firebaseMessaging() {
    const mthis = this;

    firebase
      .notifications()
      .getInitialNotification()
      .then(notificationOpen => {
        if (notificationOpen) {
          // App was opened by a notification
          // Get the action triggered by the notification being opened
          const action = notificationOpen.action;
          // Get information about the notification that was opened, this is when the app is closed and after opened clicking on the notification
          const notification = notificationOpen.notification;
          console.log('getInitialNotification', notification.data);
          //save in local storage the notification data
          setSetting(KEYS.NOTIFICATION, notification.data, true);
        }
      });

    //foreground
    this.notificationOpenedListener = firebase
      .notifications()
      .onNotificationOpened(notificationOpen => {
        // Get the action triggered by the notification being opened
        const action = notificationOpen.action;
        // Get information about the notification that was opened, this is when the app is running but is not visible
        const notification = notificationOpen.notification;
        console.log('onNotificationOpened', notification.data);
        this.openNotification(notification.data);
      });

    this.notificationDisplayedListener = firebase
      .notifications()
      .onNotificationDisplayed(notification => {
        // Process your notification as required
        // ANDROID: Remote notifications do not contain the channel ID. You will have to specify this manually if you'd like to re-display the notification.
      });
    this.notificationListener = firebase.notifications().onNotification(notification => {
      // Process your notification as required, this is when the app is running and visible
      console.log('onNotification', notification.data);

      //show an alert dialog with the notification title and description
      Alert.alert(notification.data.title, notification.data.body, [
        {
          text: 'CERRAR',
          onPress: () => {}
        },
        {
          text: 'VER',
          onPress: () => {
            //go to notification page
            this.openNotification(notification.data);
          }
        }
      ]);
    });
  }

  openNotification(data) {
    //go to notification page
    stores.appStore.navigation.navigate('notification', {
      notification: data,
      hasGoback: true
    });
  }

  componentWillUnmount() {
    this.onTokenRefreshListener();
    this.notificationOpenedListener();
    this.notificationDisplayedListener();
    this.notificationListener();
  }

  render() {
    return (
      <Provider {...stores}>
        <View
          style={{
            flex: 1,
            backgroundColor: '#003B74',
            paddingTop: 0
          }}>
          <StatusBar translucent={!IS_ANDROID} backgroundColor="#003B74" barStyle="light-content" />
          <RootStack />
        </View>
      </Provider>
    );
  }
}
