package com.lw.connectedcar;

import android.app.Application;

import com.facebook.react.ReactApplication;
import com.aakashns.reactnativedialogs.ReactNativeDialogsPackage;
import com.wix.interactable.Interactable;
import com.lw.connectedcar.cleaner.CleanerPackage;
import com.oblador.keychain.KeychainPackage;
import com.learnium.RNDeviceInfo.RNDeviceInfo;

import io.invertase.firebase.RNFirebasePackage;

import com.airbnb.android.react.lottie.LottiePackage;
import com.oblador.vectoricons.VectorIconsPackage;
import com.BV.LinearGradient.LinearGradientPackage;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.react.shell.MainReactPackage;
import com.facebook.soloader.SoLoader;

import java.util.Arrays;
import java.util.List;

import com.airbnb.android.react.maps.MapsPackage;//react-native-maps
import com.agontuk.RNFusedLocation.RNFusedLocationPackage;//gps tracker
import com.rnfingerprint.FingerprintAuthPackage;

import io.invertase.firebase.fabric.crashlytics.RNFirebaseCrashlyticsPackage;
import io.invertase.firebase.analytics.RNFirebaseAnalyticsPackage;

import io.invertase.firebase.messaging.RNFirebaseMessagingPackage;
import io.invertase.firebase.notifications.RNFirebaseNotificationsPackage;
import br.com.classapp.RNSensitiveInfo.RNSensitiveInfoPackage;

public class MainApplication extends Application implements ReactApplication {

    private final ReactNativeHost mReactNativeHost = new ReactNativeHost(this) {
        @Override
        public boolean getUseDeveloperSupport() {
            return BuildConfig.DEBUG;
        }

        @Override
        protected List<ReactPackage> getPackages() {
            return Arrays.<ReactPackage>asList(
                    new MainReactPackage(),
            new ReactNativeDialogsPackage(),
            new Interactable(),
                    new KeychainPackage(),
                    new RNDeviceInfo(),
                    new RNFirebasePackage(),
                    new LottiePackage(),
                    new VectorIconsPackage(),
                    new LinearGradientPackage(),
                    new MapsPackage(),//react-native-maps
                    new RNFusedLocationPackage(),
                    new RNFirebaseCrashlyticsPackage(),
                    new RNFirebaseAnalyticsPackage(),
                    new RNFirebaseMessagingPackage(),
                    new RNFirebaseNotificationsPackage(),
                    new FingerprintAuthPackage(),
                    new RNSensitiveInfoPackage(),
                    new CleanerPackage()
            );
        }

        @Override
        protected String getJSMainModuleName() {
            return "index";
        }
    };

    @Override
    public ReactNativeHost getReactNativeHost() {
        return mReactNativeHost;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        SoLoader.init(this, /* native exopackage */ false);
    }
}
