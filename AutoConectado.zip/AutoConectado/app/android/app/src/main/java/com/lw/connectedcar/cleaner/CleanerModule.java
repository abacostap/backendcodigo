package com.lw.connectedcar.cleaner;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class CleanerModule extends ReactContextBaseJavaModule {
    public CleanerModule(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Override
    public String getName() {
        return "CleanerAndroid";
    }


    @ReactMethod
    public void clearData() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            try {
                ((ActivityManager) getReactApplicationContext().getSystemService(Context.ACTIVITY_SERVICE)).clearApplicationUserData();
            } catch (NullPointerException e) {

            }
        }
    }


}
