import React from 'react';

import { LayoutAnimation, TouchableOpacity, View } from 'react-native';

import PropTypes from 'prop-types';

import LinearGradient from 'react-native-linear-gradient';
import GestureRecognizer from 'react-native-swipe-gestures';
//style framework
import { IS_IPHONE_X, styles as dm, w } from '../utils/framework';

const propTypes = {
  height: PropTypes.number.isRequired //this prop is required
};

const SHADOW_HEIGHT = 80;

export default class BottomSheet extends React.Component {
  state = {
    maxHeight: this.props.height,
    height: -SHADOW_HEIGHT / 2,
    expanded: false
  };

  setMaxHeigth(maxHeight) {
    this.setState({ maxHeight });
  }

  onSwipeDown = gestureState => {
    this.onPanelUpdate();
  };

  openPanel = () => {
    this.setState({
      expanded: true
    });
    setTimeout(() => {
      LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
      this.setState({
        height: this.state.maxHeight
      });
      if (this.props.onChange) {
        this.props.onChange(true); //comunicate to parent component that state has been changed
      }
    }, 100);
  };

  closePanel = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({
      height: -SHADOW_HEIGHT / 2
    });
    if (this.props.onChange) {
      this.props.onChange(false); //comunicate to parent component that state has been changed
    }
    setTimeout(() => {
      this.setState({
        expanded: false
      });
    }, 260);
  };

  render() {
    const { height, maxHeight, expanded } = this.state;
    if (!expanded) return null;
    return (
      <View style={{ ...dm.fill }}>
        <View
          style={{
            ...dm.w_100p,
            ...dm.h_100p,
            backgroundColor: 'rgba(0,0,0,0.3)'
          }}>
          <TouchableOpacity onPress={this.closePanel} style={{ ...dm.fill }} />
          <View
            style={{
              width: w,
              height: height + SHADOW_HEIGHT / 2,
              position: 'absolute',
              left: 0,
              bottom: 0
            }}>
            <GestureRecognizer onSwipeDown={this.closePanel}>
              <>
                <LinearGradient
                  colors={['rgba(0,0,0,0)', 'rgba(0,0,0,0.1)', 'rgba(0,0,0,0.5)']}
                  style={{
                    marginBottom: -SHADOW_HEIGHT / 3,
                    height: SHADOW_HEIGHT
                  }}
                />
                <View
                  style={{
                    width: w,
                    height: maxHeight,
                    backgroundColor: '#fff',
                    borderTopRightRadius: 0,
                    borderTopLeftRadius: 0,
                    paddingBottom: IS_IPHONE_X ? 50 : 30
                  }}>
                  {this.props.children}
                </View>
              </>
            </GestureRecognizer>
          </View>
        </View>
      </View>
    );
  }
}
