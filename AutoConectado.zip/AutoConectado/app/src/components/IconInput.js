import React, { Component } from 'react';
import { TextInput, View } from 'react-native';
import PropTypes from 'prop-types';
import { styles as dm } from '../utils/framework';
import Ionic from 'react-native-vector-icons/Ionicons';

export default class IconInput extends Component {
  static propTypes = {
    iconName: PropTypes.string.isRequired,
    placeholder: PropTypes.string.isRequired,
    keyboard: PropTypes.string,
    value: PropTypes.string,

    isPassword: PropTypes.bool,
    onChange: PropTypes.func.isRequired,
    returnKeyType: PropTypes.string
  };

  static defaultProps = {
    returnKeyType: 'go',
    value: ''
  };

  focus() {
    this.input.focus();
  }

  render() {
    const {
      iconName,
      placeholder,
      keyboard,
      isPassword,
      onChange,
      returnKeyType,
      onSubmitEditing,
      value
    } = this.props;

    return (
      <View
        style={{
          backgroundColor: '#F4F4F4',
          borderRadius: 2,
          marginVertical: 5,
          ...dm.flex_r,
          ...dm.ai_c,
          ...dm.pa_hor_5
        }}>
        <Ionic
          name={iconName}
          style={{
            marginTop: 5,
            ...dm.f_40,
            ...dm.w_40,
            ...dm.t_ac,
            color: '#D8D8D8'
          }}
        />
        {isPassword && (
          <TextInput
            ref={ref => (this.input = ref)}
            onChangeText={text => onChange(text)}
            secureTextEntry
            returnKeyType={returnKeyType}
            autoFocus={false}
            value={value}
            underlineColorAndroid="transparent"
            placeholder={placeholder}
            onSubmitEditing={event => {
              if (onSubmitEditing) {
                onSubmitEditing(event);
              }
            }}
            style={{ ...dm.f_18, marginLeft: 10, flex: 1, paddingVertical: 13 }}
          />
        )}
        {!isPassword && (
          <TextInput
            ref={ref => (this.input = ref)}
            returnKeyType={returnKeyType}
            onChangeText={text => onChange(text)}
            keyboardType={keyboard}
            value={value}
            underlineColorAndroid="transparent"
            placeholder={placeholder}
            onSubmitEditing={event => {
              if (onSubmitEditing) {
                onSubmitEditing(event);
              }
            }}
            autoFocus={false}
            style={{ ...dm.f_18, marginLeft: 10, flex: 1, paddingVertical: 13 }}
          />
        )}
      </View>
    );
  }
}
