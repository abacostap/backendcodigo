import React from 'react';

import { ActivityIndicator, Modal, View } from 'react-native';
import PropTypes from 'prop-types';

import { IS_ANDROID, styles as dm } from '../utils/framework';

const propTypes = {
  visible: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  opacity: PropTypes.number
};

//default props value
const defaultProps = {
  visible: false,
  opacity: 0.9
};

export default class ModalLoading extends React.PureComponent {
  render() {
    const { visible, onClose, opacity } = this.props;
    return (
      <Modal
        presentationStyle="overFullScreen"
        animationType="fade"
        transparent={true}
        visible={visible}
        onRequestClose={() => onClose()}>
        <View
          style={{
            ...dm.fill,
            ...dm.jc_c,
            ...dm.ai_c,
            backgroundColor: `rgba(255,255,255,${opacity})`
          }}>
          <ActivityIndicator size={IS_ANDROID ? 80 : 'large'} color={consts.PRIMARY} />
        </View>
      </Modal>
    );
  }
}

ModalLoading.propTypes = propTypes;
ModalLoading.defaultProps = defaultProps;
