import React from 'react';
import { Dimensions, View } from 'react-native';

import LottieView from 'lottie-react-native';

const WIDTH = Dimensions.get('window').width; //device width

const PinLoading = () => (
  <View style={{ width: WIDTH, height: 150 }}>
    <LottieView
      source={require('../utils/lottie/PinJump.json')}
      autoPlay
      loop
      resizeMode="contain"
    />
  </View>
);

export default PinLoading;
