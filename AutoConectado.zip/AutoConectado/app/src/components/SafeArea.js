import React, { Component } from 'react';
import { View } from 'react-native';
import { IS_ANDROID, STATUSBAR_HEIGHT } from '../utils/framework';
import CONST from '../utils/consts';

export default class SafeArea extends Component {
  render() {
    return (
      <View
        style={{
          flex: 1,
          paddingTop: IS_ANDROID ? 0 : STATUSBAR_HEIGHT,
          backgroundColor: CONST.PRIMARY
        }}>
        {this.props.children}
      </View>
    );
  }
}
