import React from 'react';
import { Text, View } from 'react-native';
import PropTypes from 'prop-types';

import { RF, styles as dm } from '../utils/framework';

export default class Score extends React.PureComponent {
  static propTypes = {
    topText: PropTypes.any.isRequired,
    topSmallText: PropTypes.any,
    bottomText: PropTypes.any.isRequired,
    topColor: PropTypes.string,
    bottomColor: PropTypes.string,
    extraStyle: PropTypes.object,
    fontSizeTop: PropTypes.number,
    fontSizeTopSmall: PropTypes.number
  };

  static defaultProps = {
    topColor: '#263238',
    bottomColor: '#263238',
    extraStyle: { flex: 2 },
    fontSizeTop: RF(3.6),
    fontSizeTopSmall: RF(1.5)
  };

  render() {
    const {
      topColor,
      bottomColor,
      topText,
      topSmallText,
      bottomText,
      extraStyle,
      fontSizeTop,
      fontSizeTopSmall
    } = this.props;
    return (
      <View style={{ ...dm.ai_c, ...dm.pa_hor_10, ...extraStyle }}>
        <View style={{ ...dm.flex_r, ...dm.ai_fe }}>
          <Text style={{ color: topColor, fontSize: fontSizeTop }}>{topText}</Text>
          {topSmallText && (
            <Text
              style={{
                ...dm.ma_b_5,
                color: topColor,
                fontSize: fontSizeTopSmall
              }}>
              {topSmallText}
            </Text>
          )}
        </View>
        <Text numberOfLines={2} style={{ ...dm.f_15, ...dm.t_ac }}>
          {bottomText}
        </Text>
      </View>
    );
  }
}
