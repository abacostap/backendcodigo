import React from 'react';

import { LayoutAnimation, Text, TouchableOpacity, View } from 'react-native';
//icons
import Ionic from 'react-native-vector-icons/dist/Ionicons';

import consts from '../utils/consts'; //constants
//style framework
import { styles as dm, w } from '../utils/framework';

const SECURE_ITEM_HEIGHT = 55;

export default class SecureSelected extends React.Component {
  state = {
    expanded: false, //is true if the panel is expanded
    updatedHeight: 0, //to animate the panel height
    layoutHeight: 0, //panel height
    secures: [{}, {}, {}] //list of the all secures of a client
  };

  componentDidMount() {
    this.setState({
      layoutHeight: this.state.secures.length * SECURE_ITEM_HEIGHT + SECURE_ITEM_HEIGHT
    });
  }

  //update the component only if the state has been changed
  shouldComponentUpdate(nextProps, nextState) {
    return this.state != nextState;
  }

  //open or close thw panel
  onPanelUpdate = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);

    if (this.state.expanded == false) {
      this.setState({
        updatedHeight: this.state.layoutHeight,
        expanded: true
      });
      if (this.props.onChange) {
        this.props.onChange(true); //comunicate to parent component that state has been changed
      }
    } else {
      this.setState({
        updatedHeight: 0,
        expanded: false
      });
      if (this.props.onChange) {
        this.props.onChange(false); //comunicate to parent component that state has been changed
      }
    }
  };

  getHeight = e => {
    //alert(e.nativeEvent.layout.height)
    this.setState({ layoutHeight: e.nativeEvent.layout.height * 100 });
  };

  render() {
    const { expanded, updatedHeight, secures } = this.state;

    return (
      <View style={{ ...dm.b_white }}>
        <TouchableOpacity onPress={this.onPanelUpdate}>
          <View
            style={{
              ...dm.h_55,
              ...dm.b_secondary,
              ...dm.flex_r,
              ...dm.ai_c,
              ...dm.jc_sb,
              width: w
            }}>
            <View style={{ ...dm.flex_r, ...dm.center, ...dm.pa_l_20 }}>
              <Text
                numberOfLines={1}
                style={{
                  ...dm.c_white,
                  ...dm.f_19,
                  ...dm.pa_hor_5,
                  ...dm.ma_r_10,
                  backgroundColor: '#C840E9',
                  borderRadius: 5
                }}>
                AC
              </Text>
              <Text numberOfLines={1} style={{ ...dm.c_white, ...dm.f_19 }}>
                Hyundai IONIQ 1.6 HyBrid
              </Text>
            </View>

            <View style={{ ...dm.w_55, ...dm.h_55, ...dm.center }}>
              <Ionic
                name={expanded ? 'ios-arrow-up' : 'ios-arrow-down'}
                style={{ ...dm.f_30, ...dm.c_white }}
              />
            </View>
          </View>
        </TouchableOpacity>

        <View style={{ height: updatedHeight, overflow: 'hidden' }}>
          {/** show the secures as a small list */}
          {secures.map((item, index) => (
            <View
              style={{
                ...dm.center,
                height: SECURE_ITEM_HEIGHT,
                borderTopWidth: 1,
                borderTopColor: '#f0f0f0'
              }}
              key={index}>
              <Text> Hyundai IONIQ 1.6 HyBrid </Text>
            </View>
          ))}
          {/** end show the secures as a small list */}

          <TouchableOpacity>
            <View
              style={{
                ...dm.center,
                height: SECURE_ITEM_HEIGHT - 10,
                borderColor: consts.PRIMARY,
                borderWidth: 1,
                marginBottom: 10,
                marginHorizontal: 30,
                borderRadius: 10
              }}>
              <Text style={{ ...dm.c_primary }}>Comprar seguro en línea</Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}
