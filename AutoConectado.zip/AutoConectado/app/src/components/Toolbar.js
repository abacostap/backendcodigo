import React from 'react';

import { Image, TouchableOpacity, View } from 'react-native';

import PropTypes from 'prop-types';

import consts from '../utils/consts'; //constants
//style framework
import { styles as dm, w } from '../utils/framework';

const propTypes = {
  leftIcon: PropTypes.node, //this prop is required
  rightIcon: PropTypes.node, //this prop is required
  leftOnPress: PropTypes.func, //this prop is required, used to onPress action,
  rightOnPress: PropTypes.func //this prop is required, used to onPress action,
};

export default class Toolbar extends React.PureComponent {
  render() {
    const { leftIcon, rightIcon, leftOnPress, rightOnPress } = this.props;

    return (
      <View
        style={{
          ...dm.flex_r,
          ...dm.ai_c,
          ...dm.jc_sb,
          backgroundColor: '#003B74',
          height: consts.TOOLBAR_HEIGHT,
          width: w
        }}>
        <TouchableOpacity
          onPress={() => leftOnPress()}
          style={{ ...dm.w_55, ...dm.center, height: consts.TOOLBAR_HEIGHT }}>
          <View style={{ ...dm.w_55, ...dm.h_55, ...dm.center }}>{leftIcon}</View>
        </TouchableOpacity>

        <Image
          resizeMode="contain"
          source={require('../icons/logo.png')}
          style={{ ...dm.w_180, ...dm.h_30 }}
        />

        <View
          style={{
            ...dm.w_55,
            ...dm.ac_c,
            ...dm.jc_c,
            height: consts.TOOLBAR_HEIGHT
          }}>
          {rightIcon && (
            <TouchableOpacity
              onPress={() => rightOnPress()}
              style={{
                ...dm.w_55,
                ...dm.center,
                height: consts.TOOLBAR_HEIGHT
              }}>
              <View style={{ ...dm.w_55, ...dm.h_55, ...dm.center, ...dm.p_r }}>{rightIcon}</View>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  }
}

Toolbar.propTypes = propTypes;
