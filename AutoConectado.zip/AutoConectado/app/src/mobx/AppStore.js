import { action, observable } from 'mobx';
import { EMPTY_ARRAY } from '../utils/consts';

export default class AppStore {
  @observable homeTabIndex = 0;

  @observable homeTabData = { travels: EMPTY_ARRAY };

  @observable navigation;

  @observable user;

  @observable tabIndex = 0;

  @observable biometric = null;
  @observable touchIDActivated = false;
  @observable connected = false;

  @action
  setUser(user) {
    this.user = user;
  }

  @action
  setTabIndex(index) {
    this.tabIndex = index;
  }

  @action
  setHomeTabIndex(index) {
    this.homeTabIndex = index;
  }

  @action
  setNavigation(navigator) {
    this.navigation = navigator;
  }

  @action
  setHomeTabData(data) {
    this.homeTabData = data;
  }

  @action
  setNavigation(navigator) {
    this.navigation = navigator;
  }

  @action
  setBiometric(biometric) {
    this.biometric = biometric;
  }

  @action
  isTouchIDActivated(isActivated) {
    this.touchIDActivated = isActivated;
  }

  @action
  isConnected(connected) {
    this.connected = connected;
  }
}
