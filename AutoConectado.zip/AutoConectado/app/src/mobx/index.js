import AppStore from './AppStore';

export default {
  appStore: new AppStore()
};
