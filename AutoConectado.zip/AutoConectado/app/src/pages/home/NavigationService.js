// NavigationService.js

import { NavigationActions } from 'react-navigation';

let _navigator;

function setTopLevelNavigator(navigatorRef) {
  _navigator = navigatorRef;
}

function getTopLevelNavigator() {
  return _navigator;
}

function navigate(routeName, params) {
  _navigator.dispatch(
    NavigationActions.navigate({
      routeName,
      params
    })
  );
}

function navigateWithoutHistory(routeName, params) {
  const resetAction = NavigationActions.reset({
    index: 0,
    actions: [
      NavigationActions.navigate({
        routeName,
        params
      })
    ]
  });
  _navigator.dispatch(resetAction); //navigate to home page
}

// add other navigation functions that you need and export them

export default {
  navigate,
  navigateWithoutHistory,
  setTopLevelNavigator,
  getTopLevelNavigator
};
