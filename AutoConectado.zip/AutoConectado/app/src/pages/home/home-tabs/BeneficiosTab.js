import React from 'react';

import { Image, Text, View } from 'react-native';
import { DIAGONAL_SCREEN, styles as dm, DEVICE_WIDTH } from '../../../utils/framework';

import { inject, observer } from 'mobx-react';

const avatar_size = DIAGONAL_SCREEN * 0.12;

@inject('appStore')
@observer
class BeneficiosTab extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      visibleLoading: true
    };
  }

  render() {
    const { visibleLoading } = this.state;
    return (
      <View style={[dm.center, dm.flex_1, dm.b_white]}>
        {/* inicio avatar / puntuacion conductor */}
        <View style={[dm.ai_c, { width: DEVICE_WIDTH }]}>
          {/* inicio avatar */}
          <View style={{ paddingTop: DIAGONAL_SCREEN * 0.03, marginTop: DIAGONAL_SCREEN * 0.015 }}>
            <View style={[dm.p_r]}>
              <Image
                resizeMode="contain"
                source={{ uri: 'https://mbtskoudsalg.com/images/avatar-icon-png.png' }}
                style={{ width: avatar_size, height: avatar_size }}
              />

              <View
                style={[
                  dm.p_a,
                  dm.bottom_0,
                  dm.right_0,
                  {
                    width: 26,
                    height: 26,
                    backgroundColor: '#4CD964',
                    borderRadius: 13
                  }
                ]}
              />
            </View>
          </View>
          {/* fin avatar */}

          <Text numberOfLines={1} style={[dm.c_primary, dm.f_29, dm.f_bold, dm.ma_t_15]}>
            Fernanda Saa
          </Text>
          <Text numberOfLines={1} style={[dm.c_primary, dm.f_19, dm.ma_b_10]}>
            Excepcional
          </Text>
        </View>

        {/*fin avatar / puntuacion conductor */}
      </View>
    );
  }
}

export default BeneficiosTab;
