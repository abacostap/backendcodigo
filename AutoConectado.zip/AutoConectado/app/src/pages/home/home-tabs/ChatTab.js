import React from 'react';

import { ActivityIndicator, View, WebView } from 'react-native';
import { DIAGONAL_SCREEN, styles as dm, DEVICE_WIDTH } from '../../../utils/framework';

import { inject, observer } from 'mobx-react';
import CONSTS from '../../../utils/consts';

const avatar_size = DIAGONAL_SCREEN * 0.12;
const URL_JIVOCHAT = 'https://acmockserver.now.sh/jivochat';
@inject('appStore')
@observer
class ChatTab extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      init: false
    };
  }

  componentDidMount() {}

  render() {
    const { init } = this.state;
    return (
      <View style={{ ...dm.flex_1 }}>
        <View
          style={{
            ...dm.flex_1,
            width: DEVICE_WIDTH,
            ...dm.b_white
          }}>
          <WebView
            onError={e => {
              // alert(JSON.stringify(e));
            }}
            renderError={e => {
              //  alert(JSON.stringify(e));
            }}
            onLoadEnd={e => {
              this.setState({ init: true });
            }}
            useWebKit
            originWhitelist={['*']}
            source={{
              uri: URL_JIVOCHAT
            }}
          />
        </View>

        {!init && (
          <View style={{ ...dm.fill, ...dm.b_white, ...dm.center }}>
            <ActivityIndicator size="large" color={CONSTS.PRIMARY} />
          </View>
        )}
      </View>
    );
  }
}

export default ChatTab;
