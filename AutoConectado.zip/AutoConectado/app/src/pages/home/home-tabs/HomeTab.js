import React from 'react';
//react native components
import { Image, RefreshControl, ScrollView, Text, TouchableOpacity, View } from 'react-native';
//custom components
import SecureSelected from '../../../components/SecureSelected'; //custom component
import Score from '../../../components/Score'; //custom component
import firebase from 'react-native-firebase';
//lottie to animations
import LottieView from 'lottie-react-native';
//styles framework
import {
  IS_ANDROID,
  DIAGONAL_SCREEN,
  IS_IPHONE_X,
  RF,
  STATUSBAR_HEIGHT,
  DEVICE_HEIGHT,
  hp,
  wp,
  styles as dm,
  DEVICE_WIDTH
} from '../../../utils/framework';

import consts from '../../../utils/consts'; //colors, api host, TOOLBAR_HEIGHT, etc.
//recyclerview to fast performance
import { DataProvider, LayoutProvider, RecyclerListView } from 'recyclerlistview';
import { inject, observer } from 'mobx-react'; //mobx
import { intercept } from 'mobx'; //mobx

//get height for recyclerview container
var SCROLLVIEW_HEIGHT = DEVICE_HEIGHT - 2 * consts.TOOLBAR_HEIGHT - consts.BOTTOMBAR_HEIGHT;
if (IS_IPHONE_X) SCROLLVIEW_HEIGHT += STATUSBAR_HEIGHT / 2;

//configutarion for recyclerview types
const ViewTypes = {
  USER_SCORE: 0,
  TRAVELS_TEXT: 1,
  MONTH: 2,
  WEEK: 3,
  BORDER: 4,
  LOADING: 5
};

//to render in the recyclerview month text, week travels or show a border
const MonthViewTypes = {
  MONTH: 0,
  WEEK: 1,
  BORDER: 2
};

const PADDING_TRAVEL = DIAGONAL_SCREEN * 0.02;
//height to each list item acoording its type
const USER_SCORE_HEIGHT = DIAGONAL_SCREEN * 0.57;
const TRAVELS_TEXT_HEIGHT = hp(6);
const WEEK_HEIGHT = hp(12);
const MONTH_HEIGHT = hp(5);
const BORDER_HEIGHT = hp(2);
const LOADING_HEIGHT = hp(8);

//Dimensions to responsive content
const avatar_size = DIAGONAL_SCREEN * 0.12;
const points_width = DIAGONAL_SCREEN * 0.1;
const score_size = DIAGONAL_SCREEN * 0.05;
const score_radius = score_size / 2;

const emptyArray = [{}, {}]; //this is used by the recyclerview to show the user score (position 0) and travel text (position 1)

//image button with a text in the bottom
const ImageButton = props => (
  <TouchableOpacity
    onPress={() => {
      if (props.onPress) {
        props.onPress();
      }
    }}>
    <View style={[dm.ai_c, dm.ma_hor_10]}>
      <Image resizeMode="contain" source={props.image} style={{ width: wp(18), height: wp(18) }} />
      <View style={[dm.jc_c, { height: hp(6) }]}>
        <Text style={[dm.f_17, dm.ma_b_5, dm.jc_c, dm.t_ac]}>{props.text}</Text>
      </View>
    </View>
  </TouchableOpacity>
);

@inject('appStore')
@observer
class HomeTab extends React.Component {
  constructor(props) {
    super(props);

    //Create the data provider and provide method which takes in two rows of data and return if those two are different or not.
    //THIS IS VERY IMPORTANT, FORGET PERFORMANCE IF THIS IS MESSED UP
    this.dataProvider = new DataProvider((r1, r2) => {
      return r1 !== r2;
    });

    //Create the layout provider
    //First method: Given an index return the type of item e.g ListItemType1, ListItemType2 in case you have variety of items in your list/grid
    //Second: Given a type and object set the exact height and width for that type on given object, if you're using non deterministic rendering provide close estimates
    //If you need data based check you can access your data provider here
    //You'll need data in most cases, we don't provide it by default to enable things like data virtualization in the future
    //NOTE: For complex lists LayoutProvider will also be complex it would then make sense to move it to a different file
    this._layoutProvider = new LayoutProvider(
      index => {
        if (index === 0) return ViewTypes.USER_SCORE; //to render user score
        if (index === 1) return ViewTypes.TRAVELS_TEXT; //to render travel text

        const item = this.state.travels[index];
        if (item) {
          switch (item.type) {
            case MonthViewTypes.MONTH:
              return ViewTypes.MONTH; //to render user score
            case MonthViewTypes.WEEK:
              return ViewTypes.WEEK; //to render travel text
            case ViewTypes.LOADING:
              return ViewTypes.LOADING; //to render travel text
            default:
              return ViewTypes.BORDER; //to render item travel
          }
        } else {
          return ViewTypes.LOADING;
        }
      },
      (type, dim) => {
        //set Dimensions by type
        switch (type) {
          case ViewTypes.USER_SCORE:
            dim.width = DEVICE_WIDTH;
            dim.height = USER_SCORE_HEIGHT;
            break;

          case ViewTypes.TRAVELS_TEXT:
            dim.width = DEVICE_WIDTH;
            dim.height = TRAVELS_TEXT_HEIGHT;
            break;

          case ViewTypes.MONTH:
            dim.width = DEVICE_WIDTH;
            dim.height = MONTH_HEIGHT;
            break;
          case ViewTypes.WEEK:
            dim.width = DEVICE_WIDTH;
            dim.height = WEEK_HEIGHT;
            break;
          case ViewTypes.BORDER:
            dim.width = DEVICE_WIDTH;
            dim.height = BORDER_HEIGHT;
            break;
          case ViewTypes.LOADING:
            dim.width = DEVICE_WIDTH;
            dim.height = LOADING_HEIGHT;
            break;
        }
      }
    );

    this._rowRenderer = this._rowRenderer.bind(this); //

    //get data from mobx
    this.state = {
      travels: emptyArray,
      travelPage: 1, //pagination for travels results
      readMore: false, //if is true allow request to get more travels data
      enableScrollToTop: false, //if the value is true show bottom scroll to top
      enableRefresh: true, //if is true allow swipe refresh
      refresh: false, //if is true we can't do swipe refresh
      dataProvider: this.dataProvider.cloneWithRows(emptyArray), //data provider to recyclerview
      user: this.props.appStore.user,
      selectedPanelOpen: false //is true if secures panel is open
    };
  }

  componentDidMount() {
    //send the current screen to firebase.analytics
    firebase.analytics().setCurrentScreen('Home - HomeTab');

    //if the current tab is home and the user clic home button tab again go to the top of the recyclerview
    intercept(this.props.appStore, 'tabIndex', change => {
      if (change.newValue === 0 && change.object == 0) {
        if (this.state.enableScrollToTop && this.recyclerView) {
          this.recyclerView.scrollToIndex(0, true);
        }
      }
      return change;
    });
  }

  //Given type and data return the view component
  _rowRenderer(type, data) {
    const { user } = this.state;
    switch (type) {
      //render user score
      case ViewTypes.USER_SCORE:
        return (
          <View style={{ backgroundColor: '#fff' }}>
            {/* inicio avatar / puntuacion conductor */}
            <View style={[dm.ai_c, { width: DEVICE_WIDTH }]}>
              <Text
                numberOfLines={1}
                style={[dm.c_primary, dm.f_19, { marginTop: DIAGONAL_SCREEN * 0.015 }]}>
                PROMEDIO TOTAL
              </Text>
              {/* inicio avatar */}
              <View style={{ padding: DIAGONAL_SCREEN * 0.01 }}>
                <View style={[dm.p_r, dm.flex_r, dm.ai_c]}>
                  <View
                    style={[
                      {
                        paddingRight: 9,
                        paddingVertical: 5,
                        paddingLeft: 5,
                        marginRight: -5,
                        backgroundColor: consts.GREEN,
                        borderTopLeftRadius: 13,
                        borderBottomLeftRadius: 13
                      }
                    ]}>
                    <Text numberOfLines={1} style={[dm.c_white, dm.f_18, dm.f_bold]}>
                      EXC
                    </Text>
                  </View>

                  <View
                    style={{
                      width: avatar_size,
                      height: avatar_size,
                      borderWidth: 6,
                      borderColor: consts.GREEN,
                      borderRadius: avatar_size / 2
                    }}>
                    <Image
                      resizeMode="contain"
                      source={{
                        uri: 'https://mbtskoudsalg.com/images/avatar-icon-png.png'
                      }}
                      style={{
                        width: avatar_size - 12,
                        height: avatar_size - 12,
                        borderRadius: avatar_size / 2 - 12
                      }}
                    />
                  </View>

                  <View
                    style={[
                      {
                        paddingLeft: 9,
                        paddingVertical: 5,
                        paddingRight: 5,
                        marginLeft: -5,
                        backgroundColor: consts.GREEN,
                        borderTopRightRadius: 13,
                        borderBottomRightRadius: 13
                      }
                    ]}>
                    <Text numberOfLines={1} style={[dm.c_white, dm.f_18, dm.f_bold]}>
                      100
                    </Text>
                  </View>
                </View>
              </View>
              {/* fin avatar */}

              <Text numberOfLines={1} style={[dm.c_primary, dm.f_27, dm.f_bold]}>
                {`${user.name} ${user.lastName}`}
              </Text>
              <Text numberOfLines={1} style={[dm.c_primary, dm.f_16]}>
                CATEGORÍA: EXCEPCIONAL
              </Text>
            </View>

            {/* fin avatar / puntuacion conductor */}

            <View style={[dm.flex_r, { paddingTop: PADDING_TRAVEL }]}>
              <Score
                topColor={consts.ORANGE}
                topText={'15'}
                topSmallText={'%'}
                bottomText={`frenazos${'\n'}bruscos`}
                fontSizeTop={RF(4.4)}
                fontSizeTopSmall={RF(2.4)}
              />
              <Score
                topColor={consts.GREEN}
                topText={'10'}
                topSmallText={'%'}
                bottomText={`exceso${'\n'}de velocidad`}
                extraStyle={{
                  flex: 2,
                  borderColor: '#d2d2d2',
                  borderLeftWidth: 1,
                  borderRightWidth: 1
                }}
                fontSizeTop={RF(4.4)}
                fontSizeTopSmall={RF(2.4)}
              />
              <Score
                topColor={consts.GREEN}
                topText={'12'}
                topSmallText={'%'}
                bottomText={`aceleraciones${'\n'}bruscas`}
                fontSizeTop={RF(4.4)}
                fontSizeTopSmall={RF(2.4)}
              />
            </View>

            <View
              style={{
                height: DIAGONAL_SCREEN * 0.18,
                backgroundColor: '#e8e8e8',
                marginTop: DIAGONAL_SCREEN * 0.02
              }}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <View style={[dm.flex_r, dm.ma_t_20]}>
                  <ImageButton
                    onPress={() => {
                      firebase.analytics().logEvent('ubicacion_en_vivo', {});
                      this.props.appStore.navigation.navigate('liveTravel');
                    }}
                    image={require('../../../icons/recorrido.png')}
                    text={`Ubicación${'\n'}En vivo`}
                  />

                  <ImageButton
                    onPress={() => this.props.onUpdateBottomSheetDoors()}
                    image={require('../../../icons/apuertas.png')}
                    text={`Apertura${'\n'}de puertas`}
                  />

                  <ImageButton
                    onPress={() => {}}
                    image={require('../../../icons/pseguro.png')}
                    text={`Parqueo${'\n'}seguro`}
                  />

                  <ImageButton
                    onPress={() => {}}
                    image={require('../../../icons/chequeo.png')}
                    text={`Chequeo`}
                  />
                </View>
              </ScrollView>
            </View>
          </View>
        );

      //render "Historial de viajes" text
      case ViewTypes.TRAVELS_TEXT:
        return (
          <View
            style={[dm.jc_c, dm.pa_l_15, { height: TRAVELS_TEXT_HEIGHT, backgroundColor: '#fff' }]}>
            <Text numberOfLines={1} style={[dm.f_22, { color: consts.PRIMARY }]}>
              Historial de viajes
            </Text>
          </View>
        );

      //render week data
      case ViewTypes.MONTH:
        return (
          <View
            style={{
              backgroundColor: '#fff',
              height: MONTH_HEIGHT,
              justifyContent: 'flex-end'
            }}>
            <Text style={[dm.f_16, dm.pa_l_15, dm.c_primary, dm.f_bold]}>{data.month}</Text>
          </View>
        );

      //render week data
      case ViewTypes.WEEK:
        return this.WeekTravel(data);

      //render week data
      case ViewTypes.BORDER:
        return <View style={{ backgroundColor: '#ececec', height: BORDER_HEIGHT }} />;

      case ViewTypes.LOADING:
        return (
          <View
            style={[dm.w_100p, dm.center, { backgroundColor: '#ececec', height: LOADING_HEIGHT }]}>
            <LottieView
              source={require('../../../utils/lottie/material_wave_loading.json')}
              autoPlay
              loop
              resizeMode="cover"
              style={[dm.w_100, { height: LOADING_HEIGHT, marginTop: -5 }]}
            />
          </View>
        );

      default:
        return null;
    }
  }

  // render an item of the recyclerview, Score, week count, points, etc.
  WeekTravel = data => (
    <TouchableOpacity onPress={() => this.props.appStore.navigation.navigate('travels')}>
      <View style={[{ height: WEEK_HEIGHT + 1 }, dm.flex_r, dm.ai_c, dm.jc_sb, dm.b_white]}>
        <View
          style={[
            dm.ma_hor_20,
            dm.center,
            {
              width: score_size,
              height: score_size,
              backgroundColor: this._getColorByScore(data.score),
              borderRadius: score_radius
            }
          ]}>
          <Text style={[dm.f_27, dm.c_white, dm.pa_hor_5]}>{data.score}</Text>
        </View>

        <View
          style={[
            dm.flex_r,
            dm.ai_c,
            dm.jc_sb,
            dm.flex_1,
            dm.pa_r_10,
            {
              height: WEEK_HEIGHT,
              borderColor: '#ececec',
              borderBottomWidth: 1
            }
          ]}>
          <View>
            <Text style={[dm.f_22, dm.c_black]}>Semana {data.weekNumber}</Text>

            <Text style={[dm.ma_t_5, dm.f_19, { color: '#414548' }]}>
              {data.travelCount} Viajes
            </Text>
          </View>

          <View style={[dm.flex_r, dm.ai_c]}>
            <Text
              numberOfLines={1}
              style={[
                dm.f_22,
                dm.ma_l_10,
                {
                  width: points_width,
                  color: data.points > 0 ? '#414548' : consts.RED
                }
              ]}>
              {data.points > 0 ? `+${data.points}` : `${data.points}`} pts
            </Text>

            <Image
              resizeMode="contain"
              source={require('../../../icons/go.png')}
              style={[dm.w_15, dm.h_15, dm.ma_l_10]}
            />
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  /**
   * get mock data travels
   * @param {int} page
   */
  getTravels(page) {
    //GRAPGHQL QUERY
    const HOME_QUERY = `
   query{
  history{
    month
    weeks{
      score
      points
      weekNumber
      travelCount
    }
  }
}
`;

    if (this.state.readMore == true) return;

    //lock fetch data and show loading

    var tmpTravels = this.state.travels;
    tmpTravels.push({ type: ViewTypes.LOADING });
    this.setState({
      readMore: true,
      travels: tmpTravels,
      dataProvider: this.dataProvider.cloneWithRows(tmpTravels)
    });

    // if (IS_ANDROID) {
    //     setTimeout(() => {
    //         this.recyclerView.scrollToIndex(tmpTravels.length - 1, true)
    //     }, 100)
    // }

    //call graphql API
    fetch(`${consts.API_HOST}/graphql/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: HOME_QUERY })
    })
      .then(res => res.json())
      .then(({ data }) => {
        //parse json data to a json compatible with viewTypes for our recyclerview

        var tmp = [];
        data.history.forEach(element => {
          //see https://api.myjson.com/bins/1cj2sa for more info
          //save month
          tmp.push({ type: MonthViewTypes.MONTH, month: element.month });
          //loop week items
          element.weeks.forEach(week => {
            tmp.push({ type: MonthViewTypes.WEEK, ...week });
          });
          //after loop week items add a separation
          tmp.push({ type: MonthViewTypes.BORDER });
        });

        tmpTravels.splice(-1, 1); //remove loading animation
        tmpTravels = tmpTravels.concat(tmp); //concat the new array travels
        //save new data in the state
        this.setState({
          travels: tmpTravels,
          dataProvider: this.dataProvider.cloneWithRows(tmpTravels),
          refresh: false,
          readMore: false,
          travelPage: page + 1
        });
      })
      .catch(error => {
        //Alert.alert("ERROR", JSON.stringify(error))
        this.setState({ refresh: false, readMore: false });
        //send crash report
        firebase
          .crashlytics()
          .recordError(504, 'Timeout Error IMB server get last travels: ' + JSON.stringify(error));
      });
  }

  //return a color by score
  _getColorByScore(score) {
    if (score < 70) {
      return consts.RED;
    } else if (score >= 70 && score < 80) {
      return consts.ORANGE;
    } else {
      return consts.GREEN;
    }
  }

  render() {
    //get data from state
    const {
      travels,
      travelPage,
      enableRefresh,
      refresh,
      enableScrollToTop,
      readMore,
      selectedPanelOpen
    } = this.state;

    return (
      <View style={[dm.flex_1, dm.b_white]}>
        <SecureSelected
          onChange={open =>
            setTimeout(() => {
              this.setState({ selectedPanelOpen: open });
            }, 100)
          }
        />

        <ScrollView
          enabled={!IS_ANDROID}
          style={{ backgroundColor: '#fff' }}
          refreshControl={
            <RefreshControl
              refreshing={refresh}
              enabled={enableRefresh}
              onRefresh={() => {
                this.setState({
                  refresh: true,
                  travelPage: 1,
                  travels: emptyArray,
                  dataProvider: this.dataProvider.cloneWithRows(emptyArray)
                });
                setTimeout(() => {
                  this.getTravels(1);
                }, 100);
              }}
            />
          }>
          <View style={[dm.p_r, { height: SCROLLVIEW_HEIGHT }]}>
            <RecyclerListView
              ref={ref => (this.recyclerView = ref)}
              extendedState={this.state}
              onScroll={(ScrollEvent, offsetX, offsetY) => {
                this.setState({ enableRefresh: offsetY === 0 });
                var mEnableScrollToTop = offsetY > DEVICE_HEIGHT;
                if (enableScrollToTop !== mEnableScrollToTop) {
                  //for performance check if new data is  distinct to previous data
                  this.setState({ enableScrollToTop: offsetY > DEVICE_HEIGHT });
                }
              }}
              onEndReachedThreshold={DEVICE_HEIGHT / 2}
              onEndReached={() => {
                //if is the end of list
                if (travelPage < 36) {
                  //limit search only 365 days
                  this.getTravels(travelPage); //get more travels
                }
              }}
              layoutProvider={this._layoutProvider}
              dataProvider={this.state.dataProvider}
              rowRenderer={this._rowRenderer}
            />
          </View>
        </ScrollView>

        {/*button scroll to top*/}
        {enableScrollToTop && IS_ANDROID === true && !selectedPanelOpen && (
          <TouchableOpacity
            style={[
              dm.p_a,
              {
                top: consts.TOOLBAR_HEIGHT + 10,
                width: 110,
                borderRadius: 25,
                backgroundColor: '#ffa605',
                left: wp(50) - 55
              }
            ]}
            onPress={() => {
              if (travels.length === 0) {
                return;
              }

              this.recyclerView.scrollToIndex(0, true);
            }}>
            <View style={{ width: 110, paddingVertical: 10 }}>
              <Text style={[dm.c_white, dm.t_ac, dm.f_17]}>Ir al inicio</Text>
            </View>
          </TouchableOpacity>
        )}
        {/*end button scroll to top*/}
      </View>
    );
  }
}

export default HomeTab;
