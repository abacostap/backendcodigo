import React from 'react';
import PropTypes from 'prop-types';
import {
  Alert,
  KeyboardAvoidingView,
  Modal,
  ScrollView,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from 'react-native';
import {
  DIAGONAL_SCREEN,
  IS_ANDROID,
  RF,
  STATUSBAR_HEIGHT,
  styles as dm,
  DEVICE_WIDTH
} from '../../../utils/framework';
import { goToWithoutHistory } from '../../../utils/functions';
import { KEYS, logOut, setSetting, setUserInSecureStorage } from '../../../utils/settings';
import CONSTS from '../../../utils/consts';
import Dismisskeyboard from '../../../components/Dismisskeyboard';
import Ionic from 'react-native-vector-icons/Ionicons';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import AppLink from 'react-native-app-link';
import { inject, observer } from 'mobx-react';

const colorIconSize = DIAGONAL_SCREEN * 0.05;
const colorIconRadius = colorIconSize / 2;

const FORM_WIDTH = DEVICE_WIDTH - 60;
const EQUISMART_URL = IS_ANDROID ? CONSTS.EQUISMART_ANDROID : CONSTS.EQUISMART_IOS;

class InputPassword extends React.Component {
  static propTypes = {};
  static defaultProps = {};

  constructor(props) {
    super(props);

    this.state = {
      show: false
    };
  }

  render() {
    const { placeholder } = this.props;
    const { show } = this.state;
    return (
      <View
        style={{
          ...dm.flex_r,
          ...dm.ai_c,
          backgroundColor: '#f0f0f0',
          ...dm.ma_t_10,
          borderRadius: 4,
          width: FORM_WIDTH
        }}>
        <TextInput
          onChangeText={text => this.props.onChangeText(text)}
          secureTextEntry={!show}
          placeholder={placeholder}
          style={{
            ...dm.pa_hor_10,
            ...dm.flex_1,
            ...dm.h_45,
            ...dm.t_ac,
            borderRadius: 3
          }}
        />
        <TouchableOpacity
          onPress={() => this.setState({ show: !show })}
          style={{ ...dm.h_40, ...dm.w_40, ...dm.center }}>
          <MIcon name={show ? 'eye-off' : 'eye'} style={{ ...dm.f_40, color: '#c3c3c3' }} />
        </TouchableOpacity>
      </View>
    );
  }
}

class SettingType extends React.PureComponent {
  static propTypes = {
    onPress: PropTypes.func,
    isButton: PropTypes.bool
  };

  static defaultProps = {
    isButton: false,
    onPress: null
  };

  render() {
    const { isButton, onPress } = this.props;
    if (isButton) {
      return (
        <TouchableOpacity
          onPress={async () => {
            console.log(onPress);
            if (onPress) {
              onPress();
            }
          }}>
          {this.props.children}
        </TouchableOpacity>
      );
    } else {
      return this.props.children;
    }
  }
}

class Setting extends React.PureComponent {
  static propTypes = {
    icon: PropTypes.node.isRequired,
    iconColor: PropTypes.string,
    topText: PropTypes.string,
    bottomText: PropTypes.string,
    isButton: PropTypes.bool,
    hasBorderBottom: PropTypes.bool
  };

  static defaultProps = {
    iconColor: '#F50057',
    topText: '',
    bottomText: '',
    isButton: false,
    hasBorderBottom: false
  };

  render() {
    const {
      icon,
      topText,
      bottomText,
      rightView,
      iconColor,
      isButton,
      hasBorderBottom
    } = this.props;
    return (
      <SettingType isButton={isButton} onPress={this.props.onPress}>
        <View
          style={[
            dm.flex_r,
            dm.ai_c,
            dm.jc_sb,
            dm.w_100p,
            dm.pa_10,
            {
              borderBottomColor: '#ECEFF1',
              borderBottomWidth: hasBorderBottom ? 1 : 0
            }
          ]}>
          <View style={[dm.flex_1, dm.flex_r, dm.ai_c]}>
            <View
              style={[
                dm.center,
                {
                  width: colorIconSize,
                  height: colorIconSize,
                  borderRadius: colorIconRadius,
                  backgroundColor: iconColor
                }
              ]}>
              {icon}
            </View>

            <View style={{ marginLeft: 20, marginRight: 20 }}>
              <Text style={[dm.f_20, dm.f_bold]}>{topText}</Text>
              <Text numberOfLines={2} style={[dm.f_17]}>
                {bottomText}
              </Text>
            </View>
          </View>

          <View style={[dm.ma_l_20]}>{rightView}</View>
        </View>
      </SettingType>
    );
  }
}

@inject('appStore')
@observer
class TabMore extends React.Component {
  constructor(props) {
    super(props);

    this.state = { isChangingPassword: false, password: '', vpassword: '' };
  }

  onFingerprintChange = async value => {
    await this.props.appStore.isTouchIDActivated(value);
    await setSetting(KEYS.FINGERPRINT, `${value}`); //save  in the local storage
    if (value) {
      //we ask to the user if he wishes activate faceID or touchID
      const biometric = this.props.appStore.biometric;
      if (biometric) {
        Alert.alert(
          `Activar ${biometric}`,
          `¿Desea usar ${biometric} para acceder a su cuenta?`,
          [
            {
              text: 'No',
              onPress: async () => {
                await this.props.appStore.isTouchIDActivated(false);
                await setSetting(KEYS.FINGERPRINT, `false`);
              }
            },
            {
              text: 'Si',
              onPress: async () => {
                const isVerified = await setUserInSecureStorage({
                  data: this.props.appStore.user,
                  touchID: true
                });
                await this.props.appStore.isTouchIDActivated(isVerified);
                await setSetting(KEYS.FINGERPRINT, `${isVerified}`);
              }
            }
          ],
          { cancelable: false }
        );
      }
    } else {
      await setUserInSecureStorage({
        data: this.props.appStore.user,
        touchID: false
      });
    }
  };

  changePassoword = () => {
    const { password, vpassword } = this.state;
    if (password.length < 6) {
      Alert.alert('ERROR', 'la contraseña debe tener mínimo 6 digitos');
      return;
    }
    if (password !== vpassword) {
      Alert.alert('ERROR', 'las contraseñas no coinciden');
      return;
    }
    this.setState({ isChangingPassword: false, password: '', vpassword: '' });
    Alert.alert('EXITO', 'contraseña actualizada');
  };

  /**
   * open the EquiSmart App or the Google Play / App Store
   */
  openEquiSmartApp = () => {
    AppLink.maybeOpenURL(EQUISMART_URL, {
      appName: IS_ANDROID ? 'EquiSmart' : 'Equismart',
      appStoreId: '1021068245',
      appStoreLocale: 'EC',
      playStoreId: 'com.solmovsa.sesa.gui'
    })
      .then(() => {
        // do stuff
      })
      .catch(err => {
        // handle error
      });
  };

  logOut = async () => {
    await this.props.appStore.isTouchIDActivated(false);
    await logOut();
    goToWithoutHistory(this.props.appStore, 'splash');
  };

  render() {
    const { touchIDActivated, biometric } = this.props.appStore;
    const { isChangingPassword } = this.state;
    return (
      <View style={{ ...dm.ai_c, ...dm.flex_1, ...dm.b_white }}>
        <View style={{ ...dm.flex_1, backgroundColor: '#fff' }}>
          <ScrollView>
            {biometric && (
              <Setting
                topText="Bloqueo de la app"
                bottomText={`Pedir autenticación por ${biometric}${'\n'}al abrir la app`}
                rightView={
                  <Switch
                    trackColor="#2962FF"
                    value={touchIDActivated}
                    onValueChange={this.onFingerprintChange}
                  />
                }
                iconColor={CONSTS.GREEN}
                icon={
                  <MIcon
                    name="fingerprint"
                    style={{ ...dm.f_35, ...dm.c_white, lineHeight: RF(5) }}
                  />
                }
              />
            )}

            <View
              style={{
                ...dm.pa_10,
                ...dm.ma_t_10,
                borderTopWidth: 3,
                borderColor: '#ececec'
              }}>
              <Text style={{ ...dm.f_20, ...dm.f_bold, color: '#2962FF' }}>
                ASISTENCIAS Y SERVICIOS
              </Text>
            </View>
            <Setting
              topText="Chat Center"
              isButton={true}
              bottomText={'Lorem ipsum dolor sit amet'}
              hasBorderBottom
              onPress={() => this.props.goToChatTab()}
              iconColor="#2979FF"
              icon={<MIcon name="forum" style={{ ...dm.f_35, ...dm.c_white, lineHeight: RF(5) }} />}
            />

            <Setting
              topText="Administra tu Póliza"
              isButton={true}
              onPress={this.openEquiSmartApp}
              bottomText={'Lorem ipsum dolor sit amet'}
              iconColor="#00BCD4"
              icon={
                <MIcon
                  name="playlist-edit"
                  style={{ ...dm.f_35, ...dm.c_white, lineHeight: RF(5) }}
                />
              }
            />

            <View
              style={{
                ...dm.pa_10,
                ...dm.ma_t_10,
                borderTopWidth: 3,
                borderColor: '#ececec'
              }}>
              <Text style={{ ...dm.f_20, ...dm.f_bold, color: '#2962FF' }}>BENEFICIOS</Text>
            </View>
            <Setting
              topText="Red de benéficios"
              isButton
              onPress={() => this.props.goToBeneficiosTab()}
              bottomText={'Lorem ipsum dolor sit amet'}
              iconColor="#D500F9"
              icon={
                <MIcon
                  name="paper-cut-vertical"
                  style={{ ...dm.f_35, ...dm.c_white, lineHeight: RF(5) }}
                />
              }
            />

            <View
              style={{
                ...dm.pa_10,
                ...dm.ma_t_10,
                borderTopWidth: 3,
                borderColor: '#ececec'
              }}>
              <Text style={{ ...dm.f_20, ...dm.f_bold, color: '#2962FF' }}>AJUSTES GENERALES</Text>
            </View>

            <Setting
              topText="Mi Perfil"
              bottomText={'Fake User'}
              iconColor="#00796B"
              hasBorderBottom
              isButton
              onPress={() => this.props.appStore.navigation.navigate('profile')}
              icon={
                <MIcon
                  name="account-circle"
                  style={{ ...dm.f_35, ...dm.c_white, lineHeight: RF(5) }}
                />
              }
            />

            <Setting
              topText="Cuentas"
              bottomText="Lorem ipsum dolor sit amet"
              iconColor="#FFCA28"
              isButton
              onPress={() => {}}
              icon={
                <MIcon
                  name="account-multiple-plus-outline"
                  style={{ ...dm.f_35, ...dm.c_white, lineHeight: RF(5) }}
                />
              }
              hasBorderBottom
            />

            <Setting
              topText="Contraseña"
              bottomText={'* * * * * * * * * * * * * *'}
              iconColor="#FF4081"
              hasBorderBottom
              isButton
              onPress={() => this.setState({ isChangingPassword: true })}
              icon={
                <MIcon name="lastpass" style={{ ...dm.f_35, ...dm.c_white, lineHeight: RF(5) }} />
              }
            />

            <Setting
              topText="Cerrar Sesión"
              isButton
              onPress={async () => {
                Alert.alert('Confirmación requerida', '¿Está seguro de salir de su cuenta?', [
                  {
                    text: 'No',
                    onPress: () => {}
                  },
                  {
                    text: 'Si',
                    onPress: this.logOut
                  }
                ]);
              }}
              bottomText={'Eliminar datos y salir de tu cuenta'}
              iconColor="#E65100"
              icon={<MIcon name="power" style={{ ...dm.f_35, ...dm.c_white, lineHeight: RF(5) }} />}
            />
          </ScrollView>
        </View>

        {/*start password change */}
        <Modal
          ref={ref => (this.modalPassword = ref)}
          animated
          onRequestClose={() => {
            this.setState({
              isChangingPassword: false,
              password: '',
              vpassword: ''
            });
          }}
          visible={isChangingPassword}>
          <Dismisskeyboard>
            <View
              style={{
                ...dm.fill,
                ...dm.center,
                ...dm.b_primary
              }}>
              <KeyboardAvoidingView behavior="padding" enabled>
                <View style={{ ...dm.pa_hor_30 }}>
                  <Text
                    style={{
                      ...dm.f_25,
                      ...dm.c_white,
                      ...dm.t_ac,
                      ...dm.f_bold,
                      ...dm.ma_b_10
                    }}>
                    Cambio de contraseña
                  </Text>
                  <InputPassword placeholder="Contraseña actual" onChangeText={text => {}} />
                  <InputPassword
                    placeholder="Nueva contraseña"
                    onChangeText={text => this.setState({ password: text })}
                  />
                  <InputPassword
                    placeholder="Verificación nueva contraseña"
                    onChangeText={text => this.setState({ vpassword: text })}
                  />

                  <View
                    style={{
                      ...dm.flex_r,
                      ...dm.ai_c,
                      ...dm.jc_sb,
                      ...dm.ma_t_10,
                      ...dm.as_st
                    }}>
                    <TouchableOpacity
                      onPress={() =>
                        this.setState({
                          isChangingPassword: false,
                          password: '',
                          vpassword: ''
                        })
                      }>
                      <View
                        style={{
                          ...dm.h_40,
                          ...dm.pa_hor_10,
                          ...dm.center,
                          borderBottomWidth: 1,
                          borderBottomColor: '#fff'
                        }}>
                        <Text style={{ ...dm.f_19, ...dm.c_white }}>Cancelar</Text>
                      </View>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={this.changePassoword}>
                      <View
                        style={{
                          ...dm.b_white,
                          ...dm.h_40,
                          ...dm.pa_hor_30,
                          ...dm.center,
                          backgroundColor: CONSTS.ORANGE
                        }}>
                        <Text style={{ ...dm.c_white, ...dm.f_20 }}>ACTUALIZAR</Text>
                      </View>
                    </TouchableOpacity>
                  </View>
                </View>
              </KeyboardAvoidingView>

              <TouchableOpacity
                onPress={() => {
                  this.setState({ isChangingPassword: false });
                }}
                style={{
                  ...dm.p_a,
                  top: STATUSBAR_HEIGHT,
                  ...dm.right_0,
                  ...dm.pa_hor_20,
                  ...dm.pa_b_10
                }}>
                <Ionic name="ios-close" style={{ ...dm.f_60, ...dm.c_white }} />
              </TouchableOpacity>
            </View>
          </Dismisskeyboard>
        </Modal>
        {/*end password change */}
      </View>
    );
  }
}

export { Setting };
export default TabMore;
