import React, { Component } from 'react';
import { Animated, BackHandler, Image, Text, TouchableOpacity, View } from 'react-native';
import { TabView } from 'react-native-tab-view';
///custom components
import Toolbar from '../../components/Toolbar';
import BottomSheet from '../../components/BottomSheet';
import SafeArea from '../../components/SafeArea';
import call from 'react-native-phone-call';
//lottie for custom animations
import LottieView from 'lottie-react-native';
//mobx for app state
import { inject, observer } from 'mobx-react';

import {
  DIAGONAL_SCREEN,
  DEVICE_HEIGHT,
  hp,
  IS_IPHONE_X,
  STATUSBAR_HEIGHT,
  styles as dm,
  DEVICE_WIDTH,
  wp
} from '../../utils/framework'; //styles framework
import consts from '../../utils/consts'; //colors, api host, TOOLBAR_HEIGHT, etc.
import Ionic from 'react-native-vector-icons/Ionicons'; //Ionic iconos
//screeens
import HomeTab from './home-tabs/HomeTab';
import BeneficiosTab from './home-tabs/BeneficiosTab';
import ChatTab from './home-tabs/ChatTab';
import MasTab from './home-tabs/MoreTab';

//dimentions to responsive content, this help to performance
const BOTTOMSHEET_SOS_HEIGHT = DEVICE_HEIGHT / 1.5;
const BOTTOMSHEET_DOORS_HEIGHT = DEVICE_HEIGHT / 1.2;
const PADDING_BOTTOM = IS_IPHONE_X ? STATUSBAR_HEIGHT / 4 : 0;
const BOTTOMBAR_HEIGHT = IS_IPHONE_X ? 60 + STATUSBAR_HEIGHT / 2 : 60;
const SOS_BUTTON_SIZE = DIAGONAL_SCREEN * 0.09;
const BOTTOMBAR_ICON_SIZE = DIAGONAL_SCREEN * 0.037;

//constant to show bottomsheet
const BOTTOMSHEET_TYPES = {
  SOS: 0,
  OPEN_DOORS: 1
};

//keys to know which tab should be rendered
const KEYS = {
  HOME: 'home',
  BENEFICIOS: 'beneficios',
  CHAT: 'chat',
  MAS: 'mas'
};

@inject('appStore')
@observer
class HomeScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      bottomSheetIndex: BOTTOMSHEET_TYPES.SOS, //active bottomSheet
      isBottomSheetOpen: false, //is true if the bottomSheet is open
      //to simulate opening doors
      isOpeningDoors: false, //
      isOpenDoorsOK: false, //
      //tabview
      index: 0, //active tab index
      routes: [
        {
          key: KEYS.HOME, //tab key
          title: 'Inicio', //title to show
          icon: require('../../icons/home.png') //icon to show
        },
        {
          key: KEYS.BENEFICIOS,
          title: 'Beneficios',
          icon: require('../../icons/beneficios.png')
        },
        {
          key: KEYS.CHAT,
          title: 'Chat',
          icon: require('../../icons/chat.png')
        },
        {
          key: KEYS.MAS,
          title: 'Más',
          icon: require('../../icons/more.png')
        }
      ]
    };

    //capture back button on Androis
    const mthis = this;
    BackHandler.addEventListener('hardwareBackPress', function() {
      if (mthis.state.isBottomSheetOpen) {
        //only for android, if the bottomsheet is open
        mthis.bottomSheet.closePanel();
        return true;
      }

      const tabIndex = mthis.state.index;

      if (tabIndex !== 0) {
        //only for Android, if the user press back button and the tabview is not the home
        mthis.setState({ index: 0 }); // go to home tab
        mthis.props.appStore.setTabIndex(tabIndex);
        return true;
      }
      return false;
    });
  }

  renderScene = ({ route }) => {
    switch (route.key) {
      case KEYS.HOME:
        return <HomeTab onUpdateBottomSheetDoors={this.onUpdateBottomSheetDoors.bind(this)} />;
      case KEYS.BENEFICIOS:
        return <BeneficiosTab />;
      case KEYS.CHAT:
        return <ChatTab />;
      case KEYS.MAS:
        return (
          <MasTab
            goToChatTab={this.goToChatTab.bind(this)}
            goToBeneficiosTab={this.goToBeneficiosTab.bind(this)}
          />
        );
      default:
        return null;
    }
  };

  //tabBar to tabView
  _renderTabBar = props => {
    const inputRange = props.navigationState.routes.map((x, i) => i);

    return (
      <View
        style={{
          ...dm.flex_r,
          ...dm.jc_sa,
          backgroundColor: '#F7F7F7',
          height: BOTTOMBAR_HEIGHT,
          paddingBottom: PADDING_BOTTOM
        }}>
        {props.navigationState.routes.map((route, i) => {
          const color = props.position.interpolate({
            inputRange,
            outputRange: inputRange.map(inputIndex => (inputIndex === i ? '#1976D2' : '#B0BEC5'))
          });

          return (
            <TouchableOpacity
              key={i}
              style={{
                ...dm.pa_ver_10,
                ...dm.flex_1,
                marginRight: i === 1 ? wp(8) : 0,
                marginLeft: i === 2 ? wp(8) : 0
              }}
              onPress={() => {
                this.setState({ index: i });
                this.props.appStore.setTabIndex(i);
              }}>
              <View style={{ ...dm.center }}>
                <Animated.Image
                  source={route.icon}
                  resizeMode="contain"
                  style={{
                    tintColor: color,
                    width: BOTTOMBAR_ICON_SIZE,
                    height: BOTTOMBAR_ICON_SIZE
                  }}
                />
                <Animated.Text style={{ ...dm.f_15, color: color, marginTop: 2 }}>
                  {route.title}
                </Animated.Text>
              </View>
            </TouchableOpacity>
          );
        })}
      </View>
    );
  };

  componentDidMount() {}

  //this method will be called from homeTab
  async onUpdateBottomSheetDoors() {
    this.setState({ bottomSheetIndex: BOTTOMSHEET_TYPES.OPEN_DOORS });
    await this.bottomSheet.setMaxHeigth(BOTTOMSHEET_DOORS_HEIGHT);
    this.bottomSheet.openPanel();
  }

  //simulate opening doors
  simulateOpenDoors() {
    this.setState({ isOpeningDoors: true });
    setTimeout(() => {
      this.setState({ isOpeningDoors: false, isOpenDoorsOK: true });
    }, 2000);
  }

  //reset the opening doors state  to its default values
  resetBottomSheetData = () => {
    this.setState({ isOpeningDoors: false, isOpenDoorsOK: false });
  };

  goToBeneficiosTab = () => {
    const index = this.state.routes.findIndex(item => item.key === KEYS.BENEFICIOS);
    this.setState({ index });
    this.props.appStore.setTabIndex(KEYS.BENEFICIOS);
  };

  goToChatTab = () => {
    const index = this.state.routes.findIndex(item => item.key === KEYS.CHAT);
    this.setState({ index });
    this.props.appStore.setTabIndex(KEYS.CHAT);
  };

  render() {
    //get values from the  state
    const { bottomSheetIndex, isOpenDoorsOK, isOpeningDoors } = this.state;

    return (
      <SafeArea>
        <View style={{ ...dm.flex_1, ...dm.b_white }}>
          {/* start Toolbar */}
          <Toolbar
            leftIcon={
              <View style={{ ...dm.p_r }}>
                <Image
                  source={require('../../icons/gift.png')}
                  style={{ ...dm.w_25, ...dm.h_25 }}
                />
                <View
                  style={{
                    ...dm.center,
                    ...dm.p_a,
                    right: -15,
                    top: -5,
                    width: 20,
                    height: 20,
                    borderRadius: 10,
                    backgroundColor: consts.RED
                  }}>
                  <Text style={{ ...dm.f_15, ...dm.c_white }}>2</Text>
                </View>
              </View>
            }
            leftOnPress={this.goToBeneficiosTab}
            rightIcon={
              <View style={{ ...dm.p_r, ...dm.ma_r_15 }}>
                <Image
                  source={require('../../icons/bell.png')}
                  style={{ ...dm.w_25, ...dm.h_25 }}
                />
                <View
                  style={{
                    ...dm.center,
                    ...dm.p_a,
                    right: -8,
                    top: -5,
                    width: 20,
                    height: 20,
                    borderRadius: 10,
                    backgroundColor: consts.RED
                  }}>
                  <Text style={{ ...dm.f_15, ...dm.c_white }}>10</Text>
                </View>
              </View>
            }
            rightOnPress={() => {
              this.props.navigation.navigate('notifications');
            }}
          />
          {/* end Toolbar */}

          {/* start TabView */}
          <View style={{ ...dm.flex_1 }}>
            <TabView
              ref={ref => (this.tabview = ref)}
              useNativeDriver
              navigationState={{
                index: this.state.index,
                routes: this.state.routes
              }}
              onIndexChange={index => {
                this.setState({ index: index });
                this.props.appStore.setTabIndex(index);
              }}
              tabBarPosition="bottom"
              renderTabBar={this._renderTabBar}
              renderScene={this.renderScene}
            />
          </View>
          {/* end TabView */}

          {/* start button SOS */}
          <TouchableOpacity
            onPress={() => {
              this.setState({ bottomSheetIndex: BOTTOMSHEET_TYPES.SOS });
              this.bottomSheet.setMaxHeigth(BOTTOMSHEET_SOS_HEIGHT);
              setTimeout(() => {
                this.bottomSheet.openPanel();
              }, 50);
            }}
            style={{
              ...dm.w_50,
              ...dm.h_50,
              ...dm.p_a,
              bottom: IS_IPHONE_X ? 2 * PADDING_BOTTOM + 3 : 5,
              left: wp(50) - 25
            }}>
            <View
              style={{
                ...dm.w_50,
                ...dm.h_50,
                ...dm.center,
                borderRadius: 25,
                backgroundColor: consts.RED,
                marginBottom: IS_IPHONE_X ? 5 : 0
              }}>
              <Text style={{ ...dm.f_20, ...dm.c_white, ...dm.f_bold }}>SOS</Text>
            </View>
          </TouchableOpacity>
          {/* end button SOS */}

          {/* bottomSheet */}
          <BottomSheet
            onChange={open => {
              this.setState({ isBottomSheetOpen: open });
              if (!open) {
                this.resetBottomSheetData();
              }
              this.setState({ isBottomSheetOpen: open });
            }}
            ref={ref => (this.bottomSheet = ref)}>
            {bottomSheetIndex === BOTTOMSHEET_TYPES.SOS && (
              <View
                style={{
                  flex: 1,
                  justifyContent: 'space-between'
                }}>
                <View>
                  <View style={{ ...dm.flex_r, ...dm.jc_sa, ...dm.pa_t_30 }}>
                    <TouchableOpacity
                      onPress={() => {
                        this.bottomSheet.closePanel();
                      }}>
                      <View style={{ ...dm.center }}>
                        <Image
                          source={require('../../icons/aux_button.png')}
                          style={{
                            ...dm.ma_b_5,
                            ...dm.center,
                            width: SOS_BUTTON_SIZE,
                            height: SOS_BUTTON_SIZE
                          }}
                        />

                        <Text
                          style={{
                            ...dm.f_17,
                            ...dm.ma_b_5,
                            ...dm.jc_c,
                            ...dm.t_ac,
                            ...dm.c_primary
                          }}>
                          Pedir auxilio{'\n'}mecánico
                        </Text>
                      </View>
                    </TouchableOpacity>

                    <TouchableOpacity
                      onPress={() => {
                        this.bottomSheet.closePanel();
                      }}>
                      <View style={[dm.center]}>
                        <Image
                          source={require('../../icons/grua_button.png')}
                          style={{
                            ...dm.w_70,
                            ...dm.h_70,
                            ...dm.ma_b_5,
                            ...dm.center,
                            width: SOS_BUTTON_SIZE,
                            height: SOS_BUTTON_SIZE
                          }}
                        />

                        <Text
                          style={{
                            ...dm.f_17,
                            ...dm.ma_b_5,
                            ...dm.jc_c,
                            ...dm.t_ac,
                            ...dm.c_primary
                          }}>
                          Pedir una grua
                        </Text>
                      </View>
                    </TouchableOpacity>
                  </View>

                  <View style={{ ...dm.flex_r, ...dm.center }}>
                    <TouchableOpacity
                      onPress={() => {
                        call({
                          number: consts.PHONE_REPORT_SINISTER,
                          prompt: false
                        });

                        this.bottomSheet.closePanel();
                      }}>
                      <View style={{ ...dm.center }}>
                        <Image
                          source={require('../../icons/phone_button.png')}
                          style={{
                            ...dm.w_70,
                            ...dm.h_70,
                            ...dm.ma_b_5,
                            ...dm.center,
                            width: SOS_BUTTON_SIZE,
                            height: SOS_BUTTON_SIZE
                          }}
                        />
                        <Text
                          style={{
                            ...dm.f_17,
                            ...dm.ma_b_5,
                            ...dm.jc_c,
                            ...dm.t_ac,
                            ...dm.c_primary
                          }}>
                          Llamar a Equinoccial{'\n'}y reportar siniestro o robo
                        </Text>
                      </View>
                    </TouchableOpacity>
                  </View>
                </View>

                <TouchableOpacity
                  onPress={() => {
                    this.bottomSheet.closePanel();
                  }}
                  style={{
                    width: DEVICE_WIDTH,
                    bottom: BOTTOMBAR_HEIGHT - 40,
                    position: 'absolute',
                    zIndex: 999,
                    elevation: 3,
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                  <View>
                    <View
                      style={{
                        ...dm.ma_b_5,
                        ...dm.center,
                        width: SOS_BUTTON_SIZE,
                        height: SOS_BUTTON_SIZE,
                        borderRadius: SOS_BUTTON_SIZE / 2,
                        backgroundColor: consts.RED
                      }}>
                      <Ionic name="ios-close" style={{ ...dm.f_75, ...dm.c_white, ...dm.pa_t_5 }} />
                    </View>
                  </View>
                </TouchableOpacity>
              </View>
            )}

            {bottomSheetIndex === BOTTOMSHEET_TYPES.OPEN_DOORS && (
              <View
                style={{
                  flex: 1
                }}>
                <View style={{ ...dm.ai_c }}>
                  <TouchableOpacity onPress={() => this.bottomSheet.closePanel()}>
                    <View style={{ ...dm.center, ...dm.h_40, width: DEVICE_WIDTH }}>
                      <Ionic name="ios-arrow-down" style={{ ...dm.f_40, color: '#d0d0d0' }} />
                    </View>
                  </TouchableOpacity>

                  <Text
                    style={{
                      ...dm.f_23,
                      ...dm.ma_b_15,
                      ...dm.ma_t_10,
                      ...dm.jc_c,
                      ...dm.t_ac,
                      ...dm.c_primary
                    }}>
                    Apertura remota de puertas
                  </Text>
                  <Image
                    resizeMode="contain"
                    source={require('../../icons/apuertas.png')}
                    style={{ width: wp(24), height: wp(24), marginTop: 10 }}
                  />
                  <Text
                    style={{
                      ...dm.f_25,
                      ...dm.f_bold,
                      ...dm.ma_t_25,
                      ...dm.jc_c,
                      ...dm.t_ac,
                      ...dm.c_primary
                    }}>
                    Toque "Abrir" para ejecutar
                  </Text>
                  <Text
                    style={{
                      ...dm.f_18,
                      ...dm.ma_t_15,
                      ...dm.jc_c,
                      ...dm.t_ac,
                      ...dm.c_primary
                    }}>
                    Está funcion NO está disponible en algunos{'\n'}modelos de vehículos
                  </Text>

                  {/* start lottie openning doors animation */}
                  <View style={{ ...dm.w_100p, ...dm.ma_ver_20, height: hp(13) }}>
                    {isOpeningDoors && !isOpenDoorsOK && (
                      <LottieView
                        source={require('../../utils/lottie/autoconnect_loading.json')}
                        autoPlay
                        loop
                      />
                    )}
                    {!isOpeningDoors && isOpenDoorsOK && (
                      <LottieView
                        source={require('../../utils/lottie/checked_done.json')}
                        autoPlay
                        loop={false}
                      />
                    )}
                  </View>
                  {/* end lottie openning doors animation */}
                </View>

                <View style={{ ...dm.flex_r, ...dm.pa_hor_15 }}>
                  <TouchableOpacity
                    style={{ flex: 1 }}
                    onPress={() => this.bottomSheet.closePanel()}>
                    <View style={{ backgroundColor: '#e9ebef', borderRadius: 10 }}>
                      {/* if the opening doors is OK then show 'CANCELAR' text  */}
                      <Text
                        style={{
                          ...dm.f_20,
                          ...dm.f_bold,
                          ...dm.pa_ver_15,
                          ...dm.t_ac,
                          color: consts.RED
                        }}>
                        {isOpenDoorsOK ? 'CERRAR' : 'CANCELAR'}
                      </Text>
                    </View>
                  </TouchableOpacity>

                  {/* if the opening doors is OK then hide the next button */}
                  {!isOpenDoorsOK && (
                    <TouchableOpacity
                      disabled={isOpeningDoors}
                      style={{ flex: 1, marginLeft: 10 }}
                      onPress={() => this.simulateOpenDoors()}>
                      <View
                        style={{
                          backgroundColor: consts.PRIMARY,
                          borderRadius: 10
                        }}>
                        <Text
                          style={{
                            ...dm.f_20,
                            ...dm.f_bold,
                            ...dm.pa_ver_15,
                            ...dm.t_ac,
                            ...dm.c_white
                          }}>
                          ABRIR
                        </Text>
                      </View>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            )}
          </BottomSheet>
          {/* end bottomSheet */}
        </View>
      </SafeArea>
    );
  }
}

export default HomeScreen;
