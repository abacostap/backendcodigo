import React from 'react';

import { Text, View } from 'react-native';
import SafeArea from '../components/SafeArea';
import Toolbar from '../components/Toolbar';
import SecureSelected from '../components/SecureSelected';
//lottie for custom animations
import PinLoading from '../components/PinLoading';
import Ionic from 'react-native-vector-icons/Ionicons';

import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
//Geolocation plugin for ios and Android
import Geolocation from 'react-native-geolocation-service';

import { hp, RF, STATUSBAR_HEIGHT, styles as dm, DEVICE_WIDTH, wp } from '../utils/framework';

import consts from '../utils/consts';

import { calcuateAVGSpeed, getBearing, getDistanceFromLatLonInKm } from '../utils/functions';

const SPEED_SIZE = wp(43);
const SPEED_RADIUS = SPEED_SIZE / 2;

export default class LiveTravel extends React.Component {
  watchId = null; //for listening user position

  constructor(props) {
    super(props);

    this.state = {
      lat: null,
      lng: null,
      locations: [],
      mapReady: false,
      init: false,
      avgSpeed: 0,
      bearing: 0,
      timestamp: 0,
      pin: require('../icons/direction_small.png')
    };
  }

  componentDidMount() {
    setTimeout(() => {
      this.startTracking();
    }, 500);
  }

  //stop listenig user position
  removeLocationUpdates = () => {
    if (this.watchId !== null) {
      Geolocation.clearWatch(this.watchId);
      Geolocation.stopObserving();
    }
  };

  componentWillUnmount() {
    this.removeLocationUpdates();
  }

  //tracking user position
  startTracking() {
    this.watchId = Geolocation.watchPosition(
      position => {
        this.setLocation(position);
      },
      error => {
        this.startTracking();
      },
      {
        enableHighAccuracy: true, //modo de alta presicion
        distanceFilter: 0, //distancia minima para detectar un cambio en la posicion del usuario
        interval: 100, //intervalo de actualizaciones en mls
        fastestInterval: 100, //si existe un cambio dentro del tiempo dado en mls,
        showLocationDialog: true
      }
    );
  }

  //update user position in the map
  setLocation(bgLocation) {
    const { mapReady, init, locations, lat, lng } = this.state;
    //get data
    const { latitude, longitude, speed } = bgLocation.coords; //data from GPS
    const { timestamp } = bgLocation; //data from GPS

    let location = {
      lat: latitude,
      lng: longitude,
      timestamp: timestamp,
      init: true
    };
    let distance = 0; //distance between two points
    var avgSpeed = this.state.avgSpeed;

    var enableBearing = false;
    if (init === true) {
      //si se detectecto la posicion del  usuario anteriormente
      //siatancia entre la nueva posicion y la anterior en km
      distance = getDistanceFromLatLonInKm(lat, lng, location.lat, location.lng);

      //si el gps indica que nos estamos moviendo calculamos la velocidad promedio
      avgSpeed =
        speed >= 0 ? calcuateAVGSpeed(timestamp, this.state.timestamp, distance).toFixed() : 0;

      distance = speed >= 0 ? distance : 0;

      this.setState({
        avgSpeed: avgSpeed != 'NaN' ? avgSpeed : 0
      });

      if (avgSpeed >= 1) {
        //si la distancia entre la posicion actual y la posisicion anterior es mayor a 5 metros
        enableBearing = true;
        //add new location to locations
        this.setState({
          locations: locations.concat(location)
        });
      }
    }

    this.setState(location); //set user location

    //is the views are ready to draw in the map
    if (mapReady === true && this.map != null) {
      //move map to current location
      this.map.animateToCoordinate(
        {
          latitude: latitude,
          longitude: longitude
        },
        1000
      );

      //only if we have previous locations saved in the state
      if (locations.length > 1) {
        //calulate map Bearing
        const lastLocation = locations[locations.length - 2];
        if (enableBearing === true) {
          //if user is walking or driving

          //get bearing to rotate the map acoording user travel
          const bearing = getBearing(
            {
              latitude: lastLocation.lat,
              longitude: lastLocation.lng
            },
            {
              latitude: location.lat,
              longitude: location.lng
            }
          );

          //rotate map
          setTimeout(() => {
            this.setState({ bearing: bearing }); //save bearing
            try {
              this.map.animateToBearing(bearing, 800);
            } catch (err) {}
          }, 500);
        }
      }
    }
  }

  render() {
    const { lat, lng, avgSpeed, bearing, pin } = this.state;

    const MAP_HEIGHT = hp(81) - 110 + STATUSBAR_HEIGHT;
    return (
      <SafeArea>
        <View style={[dm.flex_1]}>
          <Toolbar
            leftOnPress={() => this.props.navigation.goBack()}
            leftIcon={<Ionic name="ios-arrow-round-back" style={[dm.c_white, dm.f_40]} />}
          />

          <SecureSelected />

          <View>
            <View style={[dm.center, dm.b_white, { height: hp(19) }]} />
            <View
              style={[
                dm.b_white,
                {
                  height: MAP_HEIGHT,
                  borderTopColor: consts.PRIMARY,
                  borderTopWidth: 2
                }
              ]}>
              {lat === null && (
                <View style={[dm.center, { height: hp(81) - 110 }]}>
                  <PinLoading />
                </View>
              )}

              {/**start map */}
              {lat !== null && (
                <MapView
                  ref={ref => (this.map = ref)}
                  style={[dm.fill]}
                  provider={PROVIDER_GOOGLE}
                  initialRegion={{
                    latitude: lat,
                    longitude: lng,
                    latitudeDelta: 0.002,
                    longitudeDelta: 0.002
                  }}
                  cacheEnabled
                  onMapReady={() => {
                    this.setState({ mapReady: true });
                    this.map.animateToViewingAngle(60);
                  }}>
                  {lat && (
                    <Marker.Animated
                      coordinate={{
                        latitude: lat,
                        longitude: lng
                      }}
                      style={{ transform: [{ rotate: bearing + 'deg' }] }}
                      image={pin}
                      flat
                      anchor={{ x: 0.5, y: 0.5 }}
                    />
                  )}
                </MapView>
              )}
              {/**end  map */}

              <View
                style={[
                  dm.p_a,
                  dm.center,
                  {
                    backgroundColor: '#FFF',
                    width: SPEED_SIZE,
                    height: SPEED_SIZE,
                    borderRadius: SPEED_RADIUS,
                    top: -SPEED_RADIUS,
                    left: SPEED_RADIUS * 1.3,
                    borderWidth: 2,
                    borderColor: consts.PRIMARY
                  }
                ]}>
                <Text style={[dm.f_83, dm.c_primary]}>{avgSpeed < 0 ? 0 : avgSpeed}</Text>
                <Text style={[dm.f_30, dm.c_primary, { lineHeight: RF(2.7) }]}>Km/h</Text>
              </View>
            </View>

            <View
              style={[
                dm.p_a,
                dm.flex_r,
                dm.center,
                dm.jc_sb,
                { width: DEVICE_WIDTH, height: hp(10), top: -25 }
              ]}>
              <View style={[dm.top_50, dm.center, dm.pa_hor_20]}>
                <Text style={[dm.f_18]}>Aceleración</Text>
                <Text style={[dm.f_40, dm.ma_t_10]}>03</Text>
              </View>
              <View style={[dm.top_50, dm.center, dm.pa_hor_20]}>
                <Text style={[dm.f_18]}>Frenazos</Text>
                <Text style={[dm.f_40, dm.ma_t_10]}>04</Text>
              </View>
            </View>
          </View>
        </View>
      </SafeArea>
    );
  }
}
