import React, { Component } from 'react';
import {
  Alert,
  Image,
  KeyboardAvoidingView,
  Modal,
  StatusBar,
  Text,
  TouchableOpacity,
  View
} from 'react-native';

import IconInput from '../components/IconInput';
import {
  DEVICE_HEIGHT,
  IS_ANDROID,
  IS_IPHONE_X,
  RF,
  STATUSBAR_HEIGHT,
  styles as dm,
  DEVICE_WIDTH
} from '../utils/framework';
import CONSTS from '../utils/consts';
import { goToWithoutHistory, isNullOrEmpty } from '../utils/functions';
import {
  getSetting,
  getUserFromSecureStorage,
  KEYS,
  setSetting,
  setUser,
  setUserInSecureStorage
} from '../utils/settings';
import axios from 'axios';
import validator from 'validator';

import { NavigationActions } from 'react-navigation'; // NavigationActions to navigate to another screen without history
//lottie to animations
import LottieView from 'lottie-react-native';
import { inject, observer } from 'mobx-react';

const FORM_WIDTH = DEVICE_WIDTH - 60;

const HEIGHT = IS_IPHONE_X ? DEVICE_HEIGHT + 2 * STATUSBAR_HEIGHT : DEVICE_HEIGHT;

@inject('appStore')
@observer
class Login extends Component {
  state = {
    loginEmail: 'test@test.com',
    loginPassword: 'test',
    fetching: false,
    authWithTouchOrFaceID: false
  };

  async componentDidMount() {
    try {
      StatusBar.setTranslucent(false);
      StatusBar.setBarStyle('light-content');
      const auth = await getSetting(KEYS.FINGERPRINT);
      this.setState({ authWithTouchOrFaceID: auth == 'true' });
    } catch (error) {
      alert(error.message);
    }
  }

  login = async () => {
    try {
      const { loginEmail, loginPassword } = this.state;
      this.setState({ fetching: true });
      //if the inputs are invalids
      if (isNullOrEmpty(loginEmail) || isNullOrEmpty(loginPassword)) {
        Alert.alert('ERROR', 'Datos invalidos');
        return;
      }
      if (!validator.isEmail(loginEmail)) {
        Alert.alert('ERROR', 'Correo electronico invalido');
        return;
      }

      const response = await axios.post(`${CONSTS.API_HOST}/api/login`, {
        email: loginEmail,
        password: loginPassword
      });
      await this.props.appStore.setUser(response.data);
      await this.setState({ fetching: false });

      //we ask to the user if he wishes activate faceID or touchID
      setTimeout(() => {
        //timeout after close modal on iOS
        this.checkEnableAuthByBiometric(response.data);
      }, 150);
    } catch (error) {
      this.setState({ fetching: false });
      console.log(error.response);
      Alert.alert('ERROR', error.response.data.msg || error.message);
    }
  };

  checkEnableAuthByBiometric(userData) {
    const { biometric } = this.props.appStore;
    if (biometric) {
      Alert.alert(
        `Activar ${biometric}`,
        `¿Desea usar ${biometric} para acceder a su cuenta?`,
        [
          {
            text: 'No',
            onPress: () => {
              this.saveData(userData, false);
            }
          },
          {
            text: 'Si',
            onPress: () => {
              this.saveData(userData, true);
            }
          }
        ],
        { cancelable: true }
      );
    } else {
      this.saveData(userData, false);
    }
  }

  async saveData(data, touchID) {
    try {
      const isOK = await setUserInSecureStorage({
        data: data,
        touchID: touchID,
        showError: touchID
      });
      await setSetting(KEYS.SAVED, 'true');
      await setSetting(KEYS.SAVED, 'true');
      await setSetting(KEYS.FINGERPRINT, `${isOK && touchID}`);
      await this.props.appStore.isTouchIDActivated(isOK && touchID);
      goToWithoutHistory(this.props, 'home');
    } catch (error) {
      alert(error.message);
    }
  }

  /**
   * remove the current page from the pile (history) and show a new page
   * @param routeName string the page name to navigate
   * @param params object with the params
   */
  goTo(routeName, params = {}) {
    const resetAction = NavigationActions.reset({
      index: 0,
      actions: [NavigationActions.navigate({ routeName: routeName, params: params })]
    });
    this.props.navigation.dispatch(resetAction); //navigate to home page
  }

  checkLoginByTouchId = async () => {
    try {
      const user = await getUserFromSecureStorage(true);
      const response = await axios({
        method: 'post',
        url: `${CONSTS.API_HOST}/api/check-session`,
        headers: {
          token: user.token
        }
      });
      await this.props.appStore.setUser(response.data);
      this.saveData(response.data, !IS_ANDROID);
    } catch (error) {
      alert(error.message);
    }
  };

  render() {
    const { loginEmail, loginPassword, fetching, authWithTouchOrFaceID } = this.state;
    const { biometric } = this.props.appStore;
    return (
      <View style={[dm.b_white, dm.flex_1, dm.ai_c, dm.p_r]}>
        <StatusBar translucent backgroundColor="rgba(0,0,0,0)" />
        <KeyboardAvoidingView behavior="position" enabled>
          <View style={[dm.w_100p, dm.ai_c, dm.jc_sb, { height: HEIGHT }]}>
            <View style={[dm.w_100p]}>
              <Image
                style={[dm.w_100p, dm.h_30p]}
                resizeMode="cover"
                source={require('../imgs/fondo-autoconectado.jpg')}
              />
            </View>

            <View style={{ width: FORM_WIDTH, alignSelf: 'center' }}>
              <Text style={[dm.f_40, dm.t_ac, { color: '#D8D8D8', lineHeight: RF(3.9) }]}>
                TE DAMOS LA
              </Text>

              <Text
                style={[dm.f_50, dm.t_ac, dm.f_bold, { color: '#00B3EF', lineHeight: RF(4.9) }]}>
                BIENVENIDA
              </Text>
              <View
                style={{
                  width: 50,
                  height: 5,
                  marginVertical: 10,
                  alignSelf: 'center',
                  backgroundColor: '#00B3EF'
                }}
              />
              <View style={[dm.flex_r, dm.center, dm.ma_b_20]}>
                <Text style={[dm.f_19, { color: '#A0A4A5' }]}>A LA ERA DE LOS </Text>
                <Text style={[dm.f_19, { color: '#000608' }]}>NOVOSAPIENS</Text>
              </View>

              <IconInput
                returnKeyType="next"
                onChange={text => this.setState({ loginEmail: text })}
                keyboard="email-address"
                iconName="ios-mail"
                placeholder="Correo electronico"
                value={loginEmail}
                onSubmitEditing={event => {
                  this.inputLoginPassword.focus();
                }}
              />
              <IconInput
                ref={ref => (this.inputLoginPassword = ref)}
                returnKeyType="go"
                value={loginPassword}
                onChange={text => this.setState({ loginPassword: text })}
                isPassword={true}
                iconName="ios-lock"
                onSubmitEditing={event => {
                  this.login();
                }}
                placeholder="Contraseña"
              />
              <View style={[dm.flex_r, dm.ai_c, dm.jc_sb, dm.ma_t_10]}>
                <TouchableOpacity>
                  <View
                    style={[
                      dm.b_white,
                      dm.h_40,
                      dm.center,
                      { borderBottomWidth: 1, borderBottomColor: '#979797' }
                    ]}>
                    <Text style={[dm.f_19]}>Olvido su contraseña?</Text>
                  </View>
                </TouchableOpacity>
                <TouchableOpacity onPress={this.login}>
                  <View
                    style={[
                      dm.b_white,
                      dm.h_50,
                      dm.pa_hor_30,
                      dm.center,
                      { backgroundColor: CONSTS.ORANGE }
                    ]}>
                    <Text style={[dm.c_white, dm.f_20]}>INGRESAR</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>

            {biometric && authWithTouchOrFaceID && (
              <TouchableOpacity onPress={this.checkLoginByTouchId} style={{ width: FORM_WIDTH }}>
                <View
                  style={{
                    ...dm.b_white,
                    ...dm.h_50,
                    ...dm.as_st,
                    ...dm.center,
                    borderWidth: 1,
                    ...dm.flex_r,
                    borderColor: CONSTS.ORANGE
                  }}>
                  <Image
                    source={
                      biometric == 'FaceID'
                        ? require('../icons/face-id.png')
                        : require('../icons/touch-id.png')
                    }
                    style={{ ...dm.w_40, ...dm.h_40, tintColor: CONSTS.ORANGE }}
                  />
                  <Text style={{ ...dm.f_20, color: CONSTS.ORANGE, ...dm.ma_l_10 }}>
                    Ingresar con {biometric}
                  </Text>
                </View>
              </TouchableOpacity>
            )}

            <View style={[dm.w_100p, dm.ai_c]}>
              <Image
                style={[
                  dm.h_10p,
                  dm.center,
                  { width: FORM_WIDTH, marginBottom: IS_IPHONE_X ? 30 : 0 }
                ]}
                resizeMode="contain"
                source={require('../imgs/logo_autoconectado_y_seguros.png')}
              />
            </View>
          </View>
        </KeyboardAvoidingView>

        <Modal
          visible={fetching}
          onRequestClose={() => {
            this.setState({ fetching: false });
          }}
          transparent
          style={[dm.center, dm.b_primary]}>
          <View style={[dm.flex_1, dm.center, { backgroundColor: 'rgba(0, 59, 116, 0.8)' }]}>
            <LottieView
              source={require('../utils/lottie/loading.json')}
              autoPlay
              loop
              resizeMode="contain"
              style={[dm.w_200, { height: 200 }]}
            />
          </View>
        </Modal>
      </View>
    );
  }
}

export default Login;
