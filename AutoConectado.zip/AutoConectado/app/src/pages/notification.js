import React, { Component } from 'react';
import { ActivityIndicator, Image, View, WebView } from 'react-native';
import { DEVICE_HEIGHT, styles as dm } from '../utils/framework';
import Toolbar from '../components/Toolbar';
import Ionic from 'react-native-vector-icons/Ionicons';
import SafeArea from '../components/SafeArea';
import CONSTS from '../utils/consts';
import { goToWithoutHistory } from '../utils/functions';

const TYPE = {
  image: 'image',
  html: 'html',
  url: 'url'
};
export default class NotificationPage extends Component {
  constructor(props) {
    super(props);
    const { hasGoback } = this.props.navigation.state.params;
    this.state = {
      init: false,
      notification: null,
      hasGoback
    };
  }

  componentDidMount() {
    const { notification } = this.props.navigation.state.params;
    this.setState({ notification });
    setTimeout(() => {
      this.setState({ init: true });
    }, 1500);
  }

  render() {
    const { notification, hasGoback, init } = this.state;
    return (
      <SafeArea>
        <View style={{ ...dm.flex_1 }}>
          <Toolbar
            leftOnPress={() => {
              if (hasGoback) {
                //go to the previous page
                this.props.navigation.goBack();
              } else {
                //go to home page
                goToWithoutHistory(this.props, 'home');
              }
            }}
            leftIcon={<Ionic name="ios-arrow-round-back" style={[dm.c_white, dm.f_40]} />}
          />

          {!init && (
            <View style={{ ...dm.flex_1, ...dm.b_white, ...dm.center }}>
              <ActivityIndicator size="large" color={CONSTS.PRIMARY} />
            </View>
          )}

          {init && (
            <>
              {notification && notification.type === TYPE.url && (
                <WebView javaScriptEnabled useWebKit source={{ uri: notification.content }} />
              )}

              {notification && notification.type === TYPE.html && (
                <WebView
                  useWebKit
                  originWhitelist={['*']}
                  source={{ html: notification.content }}
                />
              )}

              {notification && notification.type === TYPE.image && (
                <View style={{ ...dm.flex_1, ...dm.b_white }}>
                  <Image
                    style={{ ...dm.w_100p, height: DEVICE_HEIGHT - CONSTS.TOOLBAR_HEIGHT }}
                    resizeMode="contain"
                    source={{ uri: notification.content }}
                  />
                </View>
              )}
            </>
          )}
        </View>
      </SafeArea>
    );
  }
}

export { TYPE };
