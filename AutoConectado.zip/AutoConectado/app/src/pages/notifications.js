import React, { Component } from 'react';
import {
  Alert,
  Animated,
  Dimensions,
  ScrollView,
  Text,
  TouchableOpacity,
  View
} from 'react-native';

import { inject, observer } from 'mobx-react';
import SafeArea from '../components/SafeArea';
import Toolbar from '../components/Toolbar';
import { DIAGONAL_SCREEN, DEVICE_HEIGHT, styles as dm, DEVICE_WIDTH } from '../utils/framework';
import axios from 'axios';
import { getDateInSpanish } from '../utils/functions';
import { DataProvider, LayoutProvider, RecyclerListView } from 'recyclerlistview';
import Ionic from 'react-native-vector-icons/Ionicons';
import Interactable from 'react-native-interactable';
import Placeholder from 'rn-placeholder';
import CONSTS from '../utils/consts';
import { TYPE } from './notification';

const NOTIFICATION_ITEM_HEIGHT = DIAGONAL_SCREEN * 0.09;
const NOTIFICATION_BADGE_WIDTH = DIAGONAL_SCREEN * 0.035;
const RECYCLERVIEW_HEIGHT = DEVICE_HEIGHT - CONSTS.TOOLBAR_HEIGHT;

const VIEW_TYPES = {
  NOTIFICATION_ITEM: 0
};

const RAMDOM_COLORS = ['#00aacc', '#F50057', '#4527A0', '#00695C', '#E65100', '#2962FF'];

const Screen = Dimensions.get('window');
const placeholders = ['', '', '', '', '', '', '', '', '', ''];

//swipeable list item component
class Item extends React.PureComponent {
  mX = 0;

  constructor(props) {
    super(props);
    this._deltaX = new Animated.Value(0);
    this.ramdomColor = RAMDOM_COLORS[Math.floor(Math.random() * 5)];
  }

  onButtonDelete = () => {
    this.interactable.changePosition({ x: 0, y: 0 });
    this.props.onDelete();
  };

  onClick = () => {
    if (this.mX < 0 && this.mX !== -Math.round(NOTIFICATION_ITEM_HEIGHT)) {
      // if the item list is swiped
      this.interactable.changePosition({ x: 0, y: 0 });
      this.mX = 0;
    } else {
      this.props.onClick();
    }
  };

  render() {
    const { item, index, length, isNew } = this.props;

    const dateInSpanish = getDateInSpanish(new Date(item.date));
    return (
      <View
        style={{
          ...dm.jc_c,
          ...dm.pa_hor_5,
          height: NOTIFICATION_ITEM_HEIGHT - 4,
          marginTop: 2,
          marginBottom: 2,
          backgroundColor: 'rgba(0,0,0,0)'
        }}>
        <View
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            height: NOTIFICATION_ITEM_HEIGHT - 4
          }}
          pointerEvents="box-none">
          <Animated.View
            style={[
              {
                position: 'absolute',
                top: 0,
                left: Screen.width - 2 * NOTIFICATION_ITEM_HEIGHT,
                width: NOTIFICATION_ITEM_HEIGHT,
                height: NOTIFICATION_ITEM_HEIGHT - 4,
                backgroundColor: '#f00',
                justifyContent: 'center'
              },
              {
                transform: [
                  {
                    translateX: this._deltaX.interpolate({
                      inputRange: [-2 * NOTIFICATION_ITEM_HEIGHT, 0],
                      outputRange: [0, 2 * NOTIFICATION_ITEM_HEIGHT]
                    })
                  }
                ]
              }
            ]}>
            <TouchableOpacity
              style={{
                width: NOTIFICATION_ITEM_HEIGHT - 4,
                height: NOTIFICATION_ITEM_HEIGHT - 4,
                ...dm.center
              }}
              onPress={this.onButtonDelete}>
              <Ionic name="ios-trash" style={{ ...dm.f_40, ...dm.c_white }} />
            </TouchableOpacity>
          </Animated.View>
        </View>

        <Interactable.View
          ref={ref => (this.interactable = ref)}
          boundaries={{ right: 0, bounce: 0 }}
          onDrag={e => {
            const posX = Math.round(this._deltaX._value);
            this.mX = posX;
            this.setState({ posX });
          }}
          horizontalOnly={true}
          snapPoints={[
            {
              x: 0,
              damping: 1 - this.props.damping,
              tension: this.props.tension
            },
            {
              x: -NOTIFICATION_ITEM_HEIGHT,
              damping: 1 - this.props.damping,
              tension: this.props.tension
            }
          ]}
          animatedValueX={this._deltaX}>
          <TouchableOpacity onPress={this.onClick}>
            <View
              style={{
                left: 0,
                right: 0,
                paddingHorizontal: 7,
                ...dm.pa_ver_10,
                borderLeftWidth: 5,
                borderRadius: 5,
                borderLeftColor: this.ramdomColor,
                height: NOTIFICATION_ITEM_HEIGHT - 4,
                ...dm.ai_c,
                ...dm.flex_r,
                backgroundColor: '#fff'
              }}>
              <View style={{ ...dm.ai_c }}>
                <View
                  style={{
                    width: NOTIFICATION_BADGE_WIDTH,
                    height: NOTIFICATION_BADGE_WIDTH,
                    borderRadius: NOTIFICATION_BADGE_WIDTH / 2,
                    backgroundColor: '#fff',
                    borderWidth: 2,
                    borderColor: this.ramdomColor,
                    ...dm.center
                  }}>
                  <Text style={{ ...dm.f_18, color: this.ramdomColor }}>{dateInSpanish.day}</Text>
                </View>

                <Text style={{ ...dm.f_12, color: '#B0BEC5' }}>{dateInSpanish.dayName}</Text>

                <Text style={{ ...dm.f_16, color: '#37474F', ...dm.f_bold }}>{`${
                  dateInSpanish.hours
                }:${dateInSpanish.minutes}`}</Text>
              </View>
              <View style={{ ...dm.ma_l_15, ...dm.flex_1 }}>
                <Text style={{ ...dm.f_14, color: '#B0BEC5' }}>Seguros Equinoccial</Text>
                <Text numberOfLines={2} style={{ ...dm.f_16, ...dm.f_normal }}>
                  {item.title}
                </Text>
              </View>

              {isNew && (
                <View
                  style={{
                    width: 14,
                    height: 14,
                    borderRadius: 7,
                    ...dm.p_a,
                    ...dm.right_5,
                    ...dm.top_5,
                    backgroundColor: '#F50057'
                  }}
                />
              )}
            </View>
          </TouchableOpacity>
        </Interactable.View>
      </View>
    );
  }
}

@inject('appStore')
@observer
class Notifications extends Component {
  constructor(props) {
    super(props);
    //Create the data provider and provide method which takes in two rows of data and return if those two are different or not.
    //THIS IS VERY IMPORTANT, FORGET PERFORMANCE IF THIS IS MESSED UP
    this.dataProvider = new DataProvider((r1, r2) => {
      return r1 !== r2;
    });

    this._layoutProvider = new LayoutProvider(
      index => {
        switch (index) {
          case 0:
            return VIEW_TYPES.NOTIFICATION_ITEM;
          default:
            return VIEW_TYPES.NOTIFICATION_ITEM;
        }
      },
      (type, dim) => {
        dim.width = DEVICE_WIDTH;
        dim.height = NOTIFICATION_ITEM_HEIGHT;
      }
    );

    this._rowRenderer = this._rowRenderer.bind(this);

    this.state = {
      notificationList: [],
      dataProvider: this.dataProvider.cloneWithRows([]), //data to recyclerview
      page: 0,
      fetching: false,
      damping: 1,
      tension: 400,
      init: false
    };
  }

  /**
   * this method changes the state of a notification to wached
   */
  goToNotification = index => {
    var list = this.state.notificationList;
    list[index].isNew = false;
    this.setState({
      notificationList: list,
      dataProvider: this.dataProvider.cloneWithRows(list)
    });
    //go to notification page
    this.props.navigation.navigate('notification', {
      notification: {
        type: TYPE.url,
        title: 'hola ',
        body: 'hola ',
        content: 'http://www.segurosequinoccial.com/autoconectado/'
      },
      hasGoback: true
    });
  };

  //render an item into the recyclerview
  _rowRenderer(type, data, index) {
    return (
      <View>
        <Item
          item={data}
          index={index}
          damping={this.state.damping}
          tension={this.state.tension}
          onDelete={() => {
            this.onDelete(index);
          }}
          isNew={data.isNew}
          onClick={() => {
            this.goToNotification(index);
          }}
          length={this.state.notificationList.length}
        />
      </View>
    );
  }

  componentDidMount() {
    this.getNotifications(0);
  }

  onDelete = index => {
    var list = this.state.notificationList;
    list.splice(index, 1);
    this.setState({
      notificationList: list,
      dataProvider: this.dataProvider.cloneWithRows(list)
    });
  };

  getNotifications = async page => {
    try {
      const { notificationList, fetching } = this.state;
      if (fetching) return;
      this.setState({ fetching: true }); //this is to only make a one request to mockservers until finish the current request
      //get a fake list of notifications from mockserver
      const response = await axios({
        method: 'POST',
        url: `${CONSTS.API_HOST}/api/get-list-of-notifications`,
        data: {
          page
        }
      });

      //concat the current list with th response data
      const list = notificationList.concat(response.data);
      list.forEach(item => {
        item.isNew = Math.floor(Math.random() * 2) === 0;
      });

      //set the state
      this.setState({
        fetching: false,
        page,
        notificationList: list,
        dataProvider: this.dataProvider.cloneWithRows(list)
      });

      //hide the plceholder list
      setTimeout(() => {
        this.setState({ init: true });
      }, 1000);
    } catch (error) {
      Alert.alert('ERROR', error.message);
      this.setState({ fetching: false });
    }
  };

  onEndReached = ({ distanceFromEnd }) => {
    this.getNotifications(this.state.page + 1);
  };

  placeholder = index => (
    <View key={index} style={{ ...dm.ma_5 }}>
      <Placeholder.ImageContent
        size={60}
        animate="fade"
        lineNumber={4}
        lineSpacing={5}
        lastLineWidth="30%">
        <Text>Placeholder has finished :D</Text>
      </Placeholder.ImageContent>
    </View>
  );

  render() {
    const { dataProvider, page, init } = this.state;
    return (
      <SafeArea>
        <View style={{ ...dm.flex_1, ...dm.b_white }}>
          <Toolbar
            leftOnPress={() => this.props.navigation.goBack()}
            leftIcon={<Ionic name="ios-arrow-round-back" style={{ ...dm.c_white, ...dm.f_40 }} />}
          />

          {!init && (
            <ScrollView>{placeholders.map((item, index) => this.placeholder(index))}</ScrollView>
          )}

          {init && (
            <View
              style={{
                height: RECYCLERVIEW_HEIGHT,
                ...dm.pa_t_5,
                backgroundColor: '#f0f0f0'
              }}>
              <RecyclerListView
                ref={ref => (this.mlist = ref)}
                style={{ flex: 1 }}
                layoutProvider={this._layoutProvider}
                dataProvider={dataProvider}
                onEndReachedThreshold={DEVICE_HEIGHT / 2}
                extendedState={this.state}
                onEndReached={() => {
                  //if is the end of list
                  if (page < 36) {
                    //limit search only 365 days
                    this.getNotifications(page); //get more travels
                  }
                }}
                rowRenderer={this._rowRenderer}
              />
            </View>
          )}
        </View>
      </SafeArea>
    );
  }
}

export default Notifications;
