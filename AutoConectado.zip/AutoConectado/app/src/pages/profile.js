import React, { Component } from 'react';
import {
  ActionSheetIOS,
  ActivityIndicator,
  Alert,
  AlertIOS,
  Image,
  ScrollView,
  Switch,
  Text,
  TextInput,
  View
} from 'react-native';
import PropTypes from 'prop-types';
import { DIAGONAL_SCREEN, IS_ANDROID, RF, styles as dm } from '../utils/framework';
import Toolbar from '../components/Toolbar';
import Ionic from 'react-native-vector-icons/Ionicons';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import SafeArea from '../components/SafeArea';
import CONSTS from '../utils/consts';
import { getDateInSpanish } from '../utils/functions';
import DialogAndroid from 'react-native-dialogs';
import { Setting } from './home/home-tabs/MoreTab';
import { inject, observer } from 'mobx-react';
import DateTimePicker from 'react-native-modal-datetime-picker';

const avatar_size = DIAGONAL_SCREEN * 0.12;

class LabelInput extends React.PureComponent {
  static propTypes = {
    placeholder: PropTypes.string,
    keyboardType: PropTypes.string,
    value: PropTypes.string
  };
  static defaultProps = {
    placeholder: '',
    value: ''
  };

  render() {
    const { label, value, placeholder, keyboardType } = this.props;
    return (
      <View
        style={{
          ...dm.p_r,
          ...dm.ma_t_10,
          ...dm.flex_r,
          ...dm.ai_c,
          backgroundColor: '#f2f2f2',
          height: 40,
          borderRadius: 20,
          borderWidth: 1,
          borderColor: '#f0f0f0'
        }}>
        <View
          style={{
            flex: 1,
            backgroundColor: '#d0d0d0',
            height: 40,
            ...dm.center,
            paddingLeft: 12,
            paddingRight: 9,
            borderTopLeftRadius: 20,
            borderBottomLeftRadius: 20
          }}>
          <Text
            numberOfLines={1}
            style={{
              ...dm.c_primary,
              ...dm.f_bold,
              ...dm.f_13
            }}>
            {label}
          </Text>
        </View>

        <View style={{ flex: 3, ...dm.ma_l_10 }}>
          <TextInput
            keyboardType={keyboardType}
            value={value}
            style={{ ...dm.ai_st }}
            placeholder={placeholder}
          />
        </View>
      </View>
    );
  }
}

const TYPE = {
  image: 'image',
  html: 'html',
  url: 'url'
};

const GENDERS = {
  m: 'Masculino',
  f: 'Femenino'
};

const CIVIL_STATE = {
  single: 'Soltero',
  married: 'Casado'
};

@inject('appStore')
@observer
class ProfilePage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      init: false,
      //personal info
      isDateTimePickerVisible: false,
      birthday: new Date(),
      gender: GENDERS.m, //male or female
      civilState: CIVIL_STATE.single, // single or married
      //to switch alerts
      notificationOn: true,
      notificationOff: false,
      notificationDisconnected: true
    };
  }

  componentDidMount() {
    setTimeout(() => {
      this.setState({ init: true });
    }, 1500);
  }

  _showDateTimePicker = () => this.setState({ isDateTimePickerVisible: true });

  _hideDateTimePicker = () => this.setState({ isDateTimePickerVisible: false });

  _handleDatePicked = date => {
    console.log('A date has been picked: ', date);
    this.setState({ birthday: date });
    this._hideDateTimePicker();
  };

  selectGender = () => {
    ActionSheetIOS.showActionSheetWithOptions(
      {
        options: [GENDERS.m, GENDERS.f, 'Cancelar'],
        cancelButtonIndex: 2
      },
      buttonIndex => {
        if (buttonIndex !== 2) {
          this.setState({ gender: buttonIndex === 0 ? GENDERS.m : GENDERS.f });
        }
      }
    );
  };

  selectCivilState = () => {
    ActionSheetIOS.showActionSheetWithOptions(
      {
        options: [CIVIL_STATE.single, CIVIL_STATE.married, 'Cancelar'],
        cancelButtonIndex: 2
      },
      buttonIndex => {
        if (buttonIndex !== 2) {
          this.setState({
            civilState: buttonIndex === 0 ? CIVIL_STATE.single : CIVIL_STATE.married
          });
        }
      }
    );
  };

  setIdentificationNumber = async () => {
    const title = 'Ingrese su número de identificacion';
    if (IS_ANDROID) {
      const { action, text } = await DialogAndroid.prompt(title, '', {
        defaultValue: '1234567897'
      });
      if (action === DialogAndroid.actionPositive) {
        console.log(`You submitted: "${text}"`);
      }
    } else {
      AlertIOS.prompt(
        title,
        null,
        [
          {
            text: 'Cancelar',
            onPress: () => console.log('Cancel Pressed'),
            style: 'cancel'
          },
          {
            text: 'OK',
            onPress: text => console.log('OK Pressed ' + text)
          }
        ],
        'plain-text',
        '1234567897'
      );
    }
  };

  setName = async () => {
    const title = 'Ingrese sus nomnres y apellidos';
    const defaultValue = 'Fake User';
    if (IS_ANDROID) {
      const { action, text } = await DialogAndroid.prompt(title, '', {
        defaultValue: defaultValue
      });
      if (action === DialogAndroid.actionPositive) {
        console.log(`You submitted: "${text}"`);
      }
    } else {
      AlertIOS.prompt(
        title,
        null,
        [
          {
            text: 'Cancelar',
            onPress: () => console.log('Cancel Pressed'),
            style: 'cancel'
          },
          {
            text: 'OK',
            onPress: text => console.log('OK Pressed ' + text)
          }
        ],
        'plain-text',
        defaultValue
      );
    }
  };

  setPhoneNumber = async () => {
    const title = 'Ingrese su número telefónico';
    const defaultValue = '0987898765';
    if (IS_ANDROID) {
      const { action, text } = await DialogAndroid.prompt(title, '', {
        defaultValue: defaultValue
      });
      if (action === DialogAndroid.actionPositive) {
        console.log(`You submitted: "${text}"`);
      }
    } else {
      AlertIOS.prompt(
        title,
        null,
        [
          {
            text: 'Cancelar',
            onPress: () => console.log('Cancel Pressed'),
            style: 'cancel'
          },
          {
            text: 'OK',
            onPress: text => console.log('OK Pressed ' + text)
          }
        ],
        'plain-text',
        defaultValue
      );
    }
  };

  setEmail = async () => {
    const title = 'Ingrese su coreo electrónico';
    const defaultValue = 'fakeuser@fake.com';
    if (IS_ANDROID) {
      const { action, text } = await DialogAndroid.prompt(title, '', {
        defaultValue: defaultValue
      });
      if (action === DialogAndroid.actionPositive) {
        console.log(`You submitted: "${text}"`);
      }
    } else {
      AlertIOS.prompt(
        title,
        null,
        [
          {
            text: 'Cancelar',
            onPress: () => console.log('Cancel Pressed'),
            style: 'cancel'
          },
          {
            text: 'OK',
            onPress: text => console.log('OK Pressed ' + text)
          }
        ],
        'plain-text',
        defaultValue
      );
    }
  };

  setEmergencyName = async () => {
    const title = 'Nombre de su contacto de emergencia';
    const defaultValue = '';
    if (IS_ANDROID) {
      const { action, text } = await DialogAndroid.prompt(title, '', {
        defaultValue: defaultValue
      });
      if (action === DialogAndroid.actionPositive) {
        console.log(`You submitted: "${text}"`);
      }
    } else {
      AlertIOS.prompt(
        title,
        null,
        [
          {
            text: 'Cancelar',
            onPress: () => console.log('Cancel Pressed'),
            style: 'cancel'
          },
          {
            text: 'OK',
            onPress: text => console.log('OK Pressed ' + text)
          }
        ],
        'plain-text',
        defaultValue
      );
    }
  };

  setEmergencyRelationShip = async () => {
    const title = '¿Cúal es el parentesco de su contacto de emergencia';
    const message = 'Mi padre, madre, hermano, etc.';
    const defaultValue = 'padre';
    if (IS_ANDROID) {
      const { action, text } = await DialogAndroid.prompt(title, message, {
        defaultValue: defaultValue
      });
      if (action === DialogAndroid.actionPositive) {
        console.log(`You submitted: "${text}"`);
      }
    } else {
      AlertIOS.prompt(
        title,
        message,
        [
          {
            text: 'Cancelar',
            onPress: () => console.log('Cancel Pressed'),
            style: 'cancel'
          },
          {
            text: 'OK',
            onPress: text => console.log('OK Pressed ' + text)
          }
        ],
        'plain-text',
        defaultValue
      );
    }
  };

  setEmergencyPhoneNumber = async () => {
    const title = 'Ingrese el número telefónico de su contacto de emergencia';
    const defaultValue = '0987898765';
    if (IS_ANDROID) {
      const { action, text } = await DialogAndroid.prompt(title, '', {
        defaultValue: defaultValue
      });
      if (action === DialogAndroid.actionPositive) {
        console.log(`You submitted: "${text}"`);
      }
    } else {
      AlertIOS.prompt(
        title,
        null,
        [
          {
            text: 'Cancelar',
            onPress: () => console.log('Cancel Pressed'),
            style: 'cancel'
          },
          {
            text: 'OK',
            onPress: text => console.log('OK Pressed ' + text)
          }
        ],
        'plain-text',
        defaultValue
      );
    }
  };

  render() {
    const {
      init,
      isDateTimePickerVisible,
      birthday,
      gender,
      civilState,
      notificationDisconnected,
      notificationOn,
      notificationOff
    } = this.state;
    const { user } = this.props.appStore;
    const birthdaySpanish = getDateInSpanish(birthday);
    return (
      <SafeArea>
        <View style={{ ...dm.flex_1, ...dm.b_white }}>
          <Toolbar
            leftOnPress={() => {
              this.props.navigation.goBack();
            }}
            leftIcon={<Ionic name="ios-arrow-round-back" style={[dm.c_white, dm.f_40]} />}
          />

          {!init && (
            <View style={{ ...dm.flex_1, ...dm.b_white, ...dm.center }}>
              <ActivityIndicator size="large" color={CONSTS.PRIMARY} />
            </View>
          )}

          {init && (
            <ScrollView contentContainerStyle={{}}>
              <View style={{ ...dm.b_primary, ...dm.pa_30, ...dm.center }}>
                <Image
                  resizeMode="cover"
                  source={require('../imgs/fondo-autoconectado.jpg')}
                  style={{
                    ...dm.p_a,
                    ...dm.left_0,
                    ...dm.top_0,
                    ...dm.w_100p,
                    height: '175%'
                  }}
                />

                <View
                  style={{
                    ...dm.fill,
                    ...dm.b_primary,
                    opacity: 0.8
                  }}
                />
                <View
                  style={{
                    width: avatar_size,
                    height: avatar_size,
                    borderWidth: 3,
                    borderColor: CONSTS.GREEN,
                    borderRadius: avatar_size / 2
                  }}>
                  <Image
                    resizeMode="contain"
                    source={{
                      uri: 'https://mbtskoudsalg.com/images/avatar-icon-png.png'
                    }}
                    style={{
                      width: avatar_size - 6,
                      height: avatar_size - 6,
                      borderRadius: avatar_size / 2 - 6
                    }}
                  />
                </View>

                <View>
                  <Text
                    style={{
                      ...dm.f_20,
                      ...dm.c_white,
                      ...dm.f_bold,
                      ...dm.ma_t_10
                    }}>
                    {user.name} {user.lastName}
                  </Text>
                </View>
              </View>

              <View>
                <View style={[dm.pa_10, { borderTopWidth: 3, borderColor: '#ececec' }]}>
                  <Text style={[dm.f_20, dm.f_bold, { color: '#2962FF' }]}>DATOS PERSONALES</Text>
                </View>
                <Setting
                  topText="Número de identificación"
                  bottomText={'1234567897'}
                  iconColor="#F50057"
                  hasBorderBottom
                  isButton
                  onPress={this.setIdentificationNumber}
                  icon={
                    <MIcon
                      name="account-card-details"
                      style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]}
                    />
                  }
                />

                <Setting
                  topText="Nombres y Apellidos"
                  bottomText={'Fake User'}
                  iconColor="#2962FF"
                  hasBorderBottom
                  isButton
                  onPress={this.setName}
                  icon={
                    <MIcon
                      name="account-circle"
                      style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]}
                    />
                  }
                />

                <Setting
                  topText="Fecha de nacimiento"
                  bottomText={`${birthdaySpanish.day} de ${birthdaySpanish.monthName} ${
                    birthdaySpanish.year
                  }`}
                  iconColor="#00E676"
                  hasBorderBottom
                  isButton
                  onPress={this._showDateTimePicker}
                  icon={
                    <MIcon name="calendar" style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]} />
                  }
                />

                <Setting
                  topText="Sexo"
                  bottomText={gender}
                  iconColor="#7C4DFF"
                  hasBorderBottom
                  isButton
                  onPress={() => {
                    if (IS_ANDROID) {
                      Alert.alert(
                        'GENERO',
                        'Seleccione una opción',
                        [
                          {
                            text: GENDERS.m,
                            onPress: () => this.setState({ gender: GENDERS.m })
                          },
                          {
                            text: GENDERS.f,
                            onPress: () => this.setState({ gender: GENDERS.f })
                          }
                        ],
                        { cancelable: false }
                      );
                    } else {
                      this.selectGender();
                    }
                  }}
                  icon={
                    <MIcon
                      name="gender-male-female"
                      style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]}
                    />
                  }
                />

                <Setting
                  topText="Estado Civil"
                  bottomText={civilState}
                  iconColor="#00BFA5"
                  isButton
                  onPress={() => {
                    if (IS_ANDROID) {
                      Alert.alert(
                        'Estado Civil',
                        'Seleccione una opción',
                        [
                          {
                            text: CIVIL_STATE.single,
                            onPress: () =>
                              this.setState({
                                civilState: CIVIL_STATE.single
                              })
                          },
                          {
                            text: CIVIL_STATE.married,
                            onPress: () =>
                              this.setState({
                                civilState: CIVIL_STATE.married
                              })
                          }
                        ],
                        { cancelable: false }
                      );
                    } else {
                      this.selectCivilState();
                    }
                  }}
                  icon={
                    <MIcon name="home-heart" style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]} />
                  }
                />

                <View style={[dm.pa_10, dm.ma_t_10, { borderTopWidth: 3, borderColor: '#ececec' }]}>
                  <Text style={[dm.f_20, dm.f_bold, { color: '#2962FF' }]}>
                    MI INF. DE CONTACTO
                  </Text>
                </View>
                <Setting
                  topText="Número telefónico"
                  bottomText={'0984532412'}
                  iconColor="#FFCA28"
                  hasBorderBottom
                  isButton
                  onPress={this.setPhoneNumber}
                  icon={
                    <MIcon
                      name="cellphone-android"
                      style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]}
                    />
                  }
                />
                <Setting
                  topText="Correo electrónico"
                  bottomText={'fakeuser@fake.com'}
                  iconColor="#00796B"
                  isButton
                  onPress={this.setEmail}
                  icon={<MIcon name="at" style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]} />}
                />
              </View>

              <View style={[dm.pa_10, dm.ma_t_10, { borderTopWidth: 3, borderColor: '#ececec' }]}>
                <Text style={[dm.f_20, dm.f_bold, { color: '#2962FF' }]}>
                  CONTACTO DE EMERGENCIA
                </Text>
              </View>
              <Setting
                topText="Nombre"
                bottomText={'ingrese un nombre'}
                iconColor="#2962FF"
                hasBorderBottom
                isButton
                onPress={this.setEmergencyName}
                icon={
                  <MIcon
                    name="account-circle"
                    style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]}
                  />
                }
              />

              <Setting
                topText="Parentesco"
                bottomText={'madre, padre, hermano...'}
                iconColor="#AD1457"
                hasBorderBottom
                isButton
                icon={
                  <MIcon
                    name="account-child-circle"
                    style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]}
                  />
                }
                onPress={this.setEmergencyRelationShip}
              />
              <Setting
                topText="Número telefónico"
                bottomText={'0984532412'}
                iconColor="#FFCA28"
                isButton
                onPress={this.setEmergencyPhoneNumber}
                icon={
                  <MIcon
                    name="cellphone-android"
                    style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]}
                  />
                }
              />
              <View style={[dm.pa_10, { borderTopWidth: 3, borderColor: '#ececec' }]}>
                <Text style={[dm.f_20, dm.f_bold, { color: '#2962FF' }]}>ALERTAS</Text>
              </View>
              <Setting
                topText="Encendido del vehículo"
                bottomText="¿Notificarme cuando se encienda mi vehículo?"
                hasBorderBottom
                rightView={
                  <Switch
                    trackColor="#00E676"
                    value={notificationOn}
                    onValueChange={value => this.setState({ notificationOn: value })}
                  />
                }
                iconColor={CONSTS.GREEN}
                icon={<MIcon name="adjust" style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]} />}
              />
              <Setting
                topText="Apagado del vehículo"
                bottomText="¿Notificarme cuando se apague mi vehículo?"
                hasBorderBottom
                rightView={
                  <Switch
                    trackColor="#00E676"
                    value={notificationOff}
                    onValueChange={value => this.setState({ notificationOff: value })}
                  />
                }
                iconColor="#F50057"
                icon={
                  <MIcon name="power-off" style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]} />
                }
              />

              <Setting
                topText="Desconexión de la batería"
                bottomText="¿Notificarme cuando se desconecte la batería de mi vehículo?"
                rightView={
                  <Switch
                    trackColor="#00E676"
                    value={notificationDisconnected}
                    onValueChange={value => this.setState({ notificationDisconnected: value })}
                  />
                }
                iconColor="#3F51B5"
                icon={
                  <MIcon name="flash-off" style={[dm.f_35, dm.c_white, { lineHeight: RF(5) }]} />
                }
              />

              <View style={{ ...dm.h_40 }} />
            </ScrollView>
          )}

          <DateTimePicker
            titleIOS="Seleccione una fecha"
            confirmTextIOS="Seleccionar"
            cancelTextIOS="Cancelar"
            isVisible={isDateTimePickerVisible}
            onConfirm={this._handleDatePicked}
            onCancel={this._hideDateTimePicker}
          />
        </View>
      </SafeArea>
    );
  }
}

export { TYPE };
export default ProfilePage;
