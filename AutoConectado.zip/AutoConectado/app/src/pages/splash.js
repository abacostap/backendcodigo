import React, { Component } from 'react';
import {
  Alert,
  Image,
  NativeModules,
  PermissionsAndroid,
  Platform,
  StatusBar,
  Text,
  ToastAndroid,
  TouchableOpacity,
  View
} from 'react-native';
import TouchID from 'react-native-touch-id';
import { goToWithoutHistory } from '../utils/functions';
import { IS_ANDROID, styles as dm } from '../utils/framework';
import LottieView from 'lottie-react-native';
import axios from 'axios';
import CONSTS from '../utils/consts';
import { getSetting, getUserFromSecureStorage, KEYS, removeSetting } from '../utils/settings';

import DeviceInfo from 'react-native-device-info';

import SInfo from 'react-native-sensitive-info';
import { intercept } from 'mobx'; //mobx
import { inject, observer } from 'mobx-react';

const isTablet = DeviceInfo.isTablet();

@inject('appStore')
@observer
class Splash extends Component {
  openedByNotificationClick = false;
  notification = null;

  constructor(props) {
    super(props);
    this.state = { touchIDError: false, networkError: false };
  }

  componentWillUnmount() {
    if (IS_ANDROID) {
      StatusBar.setTranslucent(false);
    }
    // StatusBar.backgroundColor(CONSTS.PRIMARY);
  }

  componentDidMount() {
    //get the initial value for network connection (true or false)

    // this.init();
    setTimeout(() => {
      const { connected } = this.props.appStore;
      console.log('connected', connected);

      if (connected) {
        this.init();
      } else {
        this.setState({ networkError: true });
      }
    }, 200);

    //if the current connection state has changed
    intercept(this.props.appStore, 'connected', change => {
      if (change.newValue === true) {
        if (this.state.networkError) {
          // if previously  we had an error
          this.setState({ networkError: false });
          this.init(); // check the preferences
        }
      }
      return change;
    });
  }

  async init() {
    const notification = await getSetting(KEYS.NOTIFICATION, true);
    if (notification) {
      this.notification = notification;
      await removeSetting(KEYS.NOTIFICATION);
    }
    await this.props.appStore.setNavigation(this.props.navigation);
    await this.isTouchIDSupported(); //check if the phone support touchID or FaceID

    if (IS_ANDROID) {
      this.androidPermissions(); //first check location permissions
    } else {
      this.checkData();
    }
  }

  async checkData() {
    const saved = await getSetting(KEYS.SAVED);
    //goToWithoutHistory(this.props, "login");

    if (saved) {
      const auth = await getSetting(KEYS.FINGERPRINT);
      this.getUser(auth == 'true');
    } else {
      goToWithoutHistory(this.props, 'login');
    }
  }

  async androidPermissions() {
    if ((await this.hasLocationPermission()) === true) {
      this.checkData();
    } else {
      this.androidPermissions();
    }
  }

  /**
   * check android permissions
   * @returns {Promise.<boolean>}
   */
  hasLocationPermission = async () => {
    //if the user is on iOS or on android version less than 6.0
    if (!IS_ANDROID || (IS_ANDROID && Platform.Version < 23)) {
      return true;
    }

    //check permisssion
    const hasPermission = await PermissionsAndroid.check(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
    );

    if (hasPermission) return true;

    //make a request to get the permission
    const status = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
    );

    if (status === PermissionsAndroid.RESULTS.GRANTED) return true;

    if (status === PermissionsAndroid.RESULTS.DENIED) {
      //if the user did not aproved the permission
      ToastAndroid.show('Location permission denied by user.', ToastAndroid.LONG);
    } else if (status === PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN) {
      ToastAndroid.show('Location permission revoked by user.', ToastAndroid.LONG);
    }

    return false;
  };

  /**
   * check if the device  support touchID or FaceID
   */
  isTouchIDSupported = async () => {
    const isSensorAvailable = await SInfo.isSensorAvailable(); //check if the device has suppport to touchID / FaceID

    if ((IS_ANDROID && Platform.Version < 23) || !isSensorAvailable) {
      await this.props.appStore.setBiometric(null);
      return;
    }

    try {
      const result = await TouchID.isSupported();

      if (result === 'FaceID' || result === true || result === 'TouchID') {
        //get biometric type
        const biometric = result === 'FaceID' ? 'FaceID' : 'TouchID';
        await this.props.appStore.setBiometric(biometric); //save in the appStore
      }
    } catch (error) {
      console.log('biometric error', error);
    }
  };

  /**
   * get user from secure storage
   */
  getUser = async touchID => {
    const { biometric } = this.props.appStore;
    try {
      this.setState({ touchIDError: false });
      const value = await getUserFromSecureStorage(touchID);

      this.checkLogin(value, touchID);
    } catch (error) {
      //error.code==="EUNSPECIFIED"

      if (error.message == 'null') {
        if (touchID === true && IS_ANDROID) {
          Alert.alert(
            'ERROR EN DATOS BIOMETRICOS',
            'Hemos detectado un cambio en sus datos biometricos, borraremos los datos de la app en su dispositivo. Luego vuelva a abrir la app e inicie sesión',
            [
              {
                text: 'ENTENDIDO',
                onPress: () => {
                  NativeModules.CleanerAndroid.clearData();
                }
              }
            ],
            {
              cancelable: false
            }
          );
        }
      } else if (!biometric || touchID) {
        //if the user previously activated authentication by FaceId-touchId and the permissions wasn't granted
        goToWithoutHistory(this.props, 'login');
      }

      this.setState({ touchIDError: biometric ? true : false });
    }
  };

  /**
   * check if the user was loged
   */
  async checkLogin(value, touchID) {
    try {
      const data = value; //get user from the local storage
      var wasLogin = true; //the user was loged
      //check if the jwt is valid
      const response = await axios({
        method: 'post',
        url: `${CONSTS.API_HOST}/api/check-session`,
        headers: {
          token: data.token
        }
      });
      await this.props.appStore.isTouchIDActivated(touchID);
      await this.props.appStore.setUser(response.data); //save user in the store
      if (this.notification) {
        //if the app was openend by cliking a notification
        goToWithoutHistory(this.props, 'notification', {
          notification: this.notification,
          hasGoback: false
        });
      } else {
        goToWithoutHistory(this.props, 'home');
      }
    } catch (error) {
      if (wasLogin) Alert.alert('UPSS!', 'Su sesión ha expirado');
      goToWithoutHistory(this.props, 'login');
    }
  }

  render() {
    const { touchIDError, networkError } = this.state;
    const { biometric, connected } = this.props.appStore;
    return (
      <View style={{ ...dm.flex_1, ...dm.ai_c, ...dm.jc_c, ...dm.b_primary }}>
        <StatusBar translucent backgroundColor="rgba(0,0,0,0)" />
        {!touchIDError && connected && (
          <View style={[dm.w_100p, dm.h_200]}>
            <LottieView
              source={require('../utils/lottie/world_locations.json')}
              resizeMode="contain"
              autoPlay
            />
          </View>
        )}

        {touchIDError && connected && (
          <View
            style={{
              ...dm.ai_c,
              ...dm.p_a,
              ...dm.top_0,
              ...dm.left_30,
              ...dm.right_30,
              ...dm.h_100
            }}>
            <Image
              resizeMode="contain"
              source={require('../imgs/logo_autoconectado_y_seguros.png')}
              style={{ ...dm.w_90p }}
            />
          </View>
        )}

        {touchIDError && connected && (
          <View
            style={{
              ...dm.ai_c,
              ...dm.p_a,
              ...dm.bottom_30,
              ...dm.left_30,
              ...dm.right_30
            }}>
            <TouchableOpacity
              onPress={() => this.getUser(true)}
              style={{ ...dm.ma_t_20, ...dm.as_st }}>
              <View style={{ ...dm.b_secondary, ...dm.pa_hor_30, ...dm.pa_ver_15 }}>
                <Text style={{ ...dm.c_white, ...dm.f_30, ...dm.t_ac }}>ESCANEAR</Text>
              </View>
            </TouchableOpacity>
            <Text style={{ ...dm.c_white, ...dm.t_ac, ...dm.ma_t_10, ...dm.f_15 }}>
              Se ha activado la autenticación mediante {biometric}, {'\n'}
              identifícate para ingresar a tu cuenta
            </Text>
          </View>
        )}

        {networkError && !connected && (
          <View>
            <View style={[dm.w_100p, dm.h_250]}>
              <LottieView
                source={require('../utils/lottie/network_error.json')}
                resizeMode="cover"
                autoPlay
                loop={false}
              />
            </View>
            <Text style={{ ...dm.c_white, ...dm.t_ac, ...dm.ma_t_10, ...dm.f_15 }}>
              Comprueba tu conexíón a internet e intenta nuevamente
            </Text>
          </View>
        )}
      </View>
    );
  }
}

export default Splash;
