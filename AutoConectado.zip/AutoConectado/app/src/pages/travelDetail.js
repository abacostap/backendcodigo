import React from 'react';

import { Text, TouchableOpacity, View } from 'react-native';

import Toolbar from '../components/Toolbar';
import SecureSelected from '../components/SecureSelected';
import PinLoading from '../components/PinLoading';
import SafeArea from '../components/SafeArea';
import Ionic from 'react-native-vector-icons/Ionicons';
import CONSTS from '../utils/consts';
import MapView, { PROVIDER_GOOGLE } from 'react-native-maps';

import {
  DIAGONAL_SCREEN,
  IS_IPHONE_X,
  STATUSBAR_HEIGHT,
  styles as dm,
  wp
} from '../utils/framework';

import consts from '../utils/consts';

//Views DIMENSTIONS to improve performace
const PADDING_TRAVEL = DIAGONAL_SCREEN * 0.03;
const PADDING_BOTTOM = IS_IPHONE_X ? STATUSBAR_HEIGHT / 2.5 : 0;

//DIMENSTIONS TO RESPONSIVE HEIGHT AND GOOD PERFORMANCE
const PADDING_TRAVEL_RIGHT = wp(8);

const SHOW_MARKERS_BY_TYPE = {
  SPEED: 0,
  ACELERATED: 1,
  BREAK: 2
};

class TravelDetail extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      mapReady: false,
      origin: {
        lat: -0.0406172,
        lng: -78.145885
      },
      init: false,
      markersType: SHOW_MARKERS_BY_TYPE.SPEED,
      destination: { lat: -0.1834262, lng: -78.4919832 },
      coordinates: [], //array of coordinates to draw travel route
      accelerated_abrupt: [], //array
      excess_speed: [], //array
      showModalLoading: true // if the value is true show a modal dialog
    };
  }

  componentDidMount() {
    setTimeout(() => {
      this.setState({ init: true });
    }, 1000);
  }

  getRoute() {
    //this a test mockserver request to get the route from current location to Atacames
    fetch(`${CONSTS.API_HOST}/api/get-travel-data`, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        origin: this.state.origin,
        destination: this.state.destination
      })
    })
      .then(res => res.json())
      .then(json => {
        this.setState({
          showModalLoading: false
        });
        if (json.status === 200) {
          //if the response its OK
          this.setState({
            coordinates: json.coordinates,
            accelerated_abrupt: json.accelerated_abrupt,
            excess_speed: json.excess_speed
          });

          this.map.fitToElements(false);
        }
      })
      .catch(err => {
        this.setState({
          showModalLoading: false
        });
        setTimeout(() => {
          alert('ERROR: POR FAVOR REVISA TU CONEXIÓN E INTENTA NUEVAMENTE');
        }, 300);
      });
  }

  render() {
    //state
    const {
      init,
      origin,
      coordinates,
      accelerated_abrupt,
      excess_speed,
      destination,
      showModalLoading,
      markersType
    } = this.state;

    const SPEED_BUTTON_COLORS = getButtonColors(markersType, SHOW_MARKERS_BY_TYPE.SPEED);
    const ACELERATED_BUTTON_COLORS = getButtonColors(markersType, SHOW_MARKERS_BY_TYPE.ACELERATED);
    const BREAK_BUTTON_COLORS = getButtonColors(markersType, SHOW_MARKERS_BY_TYPE.BREAK);

    return (
      <SafeArea>
        <View style={[dm.flex_1, dm.b_white]}>
          {/** start Toolbar */}
          <Toolbar
            leftOnPress={() => this.props.navigation.goBack()}
            leftIcon={<Ionic name="ios-arrow-round-back" style={[dm.c_white, dm.f_40]} />}
          />
          {/** end Toolbar */}

          <SecureSelected />

          <View style={[dm.flex_r, dm.ai_c, dm.pa_hor_20, dm.ma_t_15]}>
            <View style={{ backgroundColor: '#414548', borderRadius: 10 }}>
              <Text style={[dm.f_17, dm.c_white, dm.pa_hor_10]}>HOY</Text>
            </View>
            <Text style={[dm.f_15, dm.ma_l_10]}>15 de octubre de 2017</Text>
          </View>

          {/** start travel number, score travel, kms, avg speed */}
          <View style={[dm.flex_r, dm.pa_b_10, { paddingTop: PADDING_TRAVEL }]}>
            <Text style={[dm.f_19, { flex: 1, textAlign: 'center', fontWeight: 'bold' }]}>
              Viaje 1
            </Text>
            <View
              style={[
                dm.flex_r,
                dm.ai_c,
                dm.jc_sb,
                { flex: 3, paddingRight: PADDING_TRAVEL_RIGHT }
              ]}>
              <View style={[dm.center]}>
                <Text style={[dm.f_15, dm.pa_hor_10]}>Score</Text>
                <Text style={[dm.f_28, { color: consts.GREEN }]}>77</Text>
              </View>

              <View style={[dm.center]}>
                <Text style={[dm.f_15, dm.pa_hor_10]}>Km recorridos</Text>
                <Text style={[dm.f_28]}>7.6</Text>
              </View>

              <View style={[dm.center]}>
                <Text style={[dm.f_15, dm.pa_hor_10]}>Km/h</Text>
                <Text style={[dm.f_28]}>23</Text>
              </View>
            </View>
          </View>
          {/** end travel number, score travel, kms, avg speed */}

          <View style={{ flex: 1 }}>
            {init && (
              <MapView
                ref={ref => (this.map = ref)}
                style={[dm.fill]}
                provider={PROVIDER_GOOGLE}
                initialRegion={{
                  latitude: -0.1846777,
                  longitude: -78.4807616,
                  latitudeDelta: 0.002,
                  longitudeDelta: 0.002
                }}
                onMapReady={() => {
                  this.setState({ mapReady: true });
                  this.getRoute();
                }}>
                {/*route*/}
                <MapView.Polyline coordinates={coordinates} strokeWidth={5} strokeColor="#0099cc" />
                {/*end route*/}

                {/*origin*/}
                <MapView.Marker
                  ref={marker => {
                    this.markerA = marker;
                  }}
                  coordinate={{
                    latitude: origin.lat,
                    longitude: origin.lng
                  }}
                  pinColor={'#0387d5'}
                />
                {/*end origin*/}

                {/*destination*/}
                <MapView.Marker
                  ref={marker => {
                    this.markerB = marker;
                  }}
                  coordinate={{
                    latitude: destination.lat,
                    longitude: destination.lng
                  }}
                  pinColor={'#fc0e2c'}
                />
                {/*end destination*/}

                {/*markers accelerated abrupt*/}
                {markersType === SHOW_MARKERS_BY_TYPE.ACELERATED &&
                  accelerated_abrupt.map((item, index) => (
                    <MapView.Marker
                      key={index}
                      coordinate={item.coords}
                      title={item.speed}
                      pinColor={'#ffa605'}
                    />
                  ))}
                {/* end markers accelerated abrupt*/}

                {/*markers excess_speed*/}
                {markersType === SHOW_MARKERS_BY_TYPE.SPEED &&
                  excess_speed.map((item, index) => (
                    <MapView.Marker
                      key={index}
                      coordinate={item.coords}
                      title={item.speed}
                      pinColor={'#52ce7f'}
                    />
                  ))}
                {/*end markers excess_speed*/}
              </MapView>
            )}
          </View>

          {/** inico excesos de velocidad, frenazos, etc */}
          <View style={[dm.flex_r]}>
            <TouchableOpacity
              style={{ flex: 1 }}
              onPress={() => this.setState({ markersType: SHOW_MARKERS_BY_TYPE.SPEED })}>
              <View
                style={[
                  dm.ai_c,
                  dm.pa_ver_5,
                  {
                    flex: 1,
                    paddingBottom: PADDING_BOTTOM,
                    backgroundColor: SPEED_BUTTON_COLORS.backgroundColor
                  }
                ]}>
                <Text numberOfLines={1} style={[dm.f_18, { color: SPEED_BUTTON_COLORS.textColor }]}>
                  {excess_speed.length}
                </Text>
                <Text style={[dm.f_18, dm.t_ac, { color: SPEED_BUTTON_COLORS.textColor }]}>
                  Excesos de{'\n'}velocidad
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                flex: 1,
                borderColor: '#d2d2d2',
                borderLeftWidth: 1,
                borderRightWidth: 1,
                backgroundColor: ACELERATED_BUTTON_COLORS.backgroundColor
              }}
              onPress={() => this.setState({ markersType: SHOW_MARKERS_BY_TYPE.ACELERATED })}>
              <View
                tyle={[
                  dm.ai_c,
                  dm.pa_ver_5,
                  {
                    flex: 1,
                    paddingBottom: PADDING_BOTTOM
                  }
                ]}>
                <Text
                  numberOfLines={1}
                  style={[dm.f_18, dm.t_ac, { color: ACELERATED_BUTTON_COLORS.textColor }]}>
                  {accelerated_abrupt.length}
                </Text>
                <Text style={[dm.f_18, dm.t_ac, { color: ACELERATED_BUTTON_COLORS.textColor }]}>
                  Aceleraciones{'\n'}bruscas
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={{ flex: 1 }}
              onPress={() => this.setState({ markersType: SHOW_MARKERS_BY_TYPE.BREAK })}>
              <View
                style={[
                  dm.ai_c,
                  dm.pa_ver_5,
                  {
                    paddingBottom: PADDING_BOTTOM,
                    backgroundColor: BREAK_BUTTON_COLORS.backgroundColor
                  }
                ]}>
                <Text numberOfLines={1} style={[dm.f_18, { color: BREAK_BUTTON_COLORS.textColor }]}>
                  0
                </Text>
                <Text style={[dm.f_18, dm.t_ac, { color: BREAK_BUTTON_COLORS.textColor }]}>
                  Frenazos{'\n'}bruscos
                </Text>
              </View>
            </TouchableOpacity>
          </View>
          {/** fin excesos de velocidad, frenazos, etc */}

          {showModalLoading && (
            <View
              style={[
                dm.center,
                dm.p_a,
                dm.left_0,
                dm.right_0,
                dm.bottom_0,
                dm.b_white,
                { top: consts.TOOLBAR_HEIGHT }
              ]}>
              <PinLoading />
            </View>
          )}
        </View>
      </SafeArea>
    );
  }
}

function getButtonColors(markersType, markerCompare) {
  var colors = { backgroundColor: '#fff', textColor: '#000' };
  if (markersType === markerCompare) {
    colors = { backgroundColor: consts.PRIMARY, textColor: '#fff' };
  }
  return colors;
}

export default TravelDetail;
