import React from 'react';

import { Text, TouchableOpacity, View } from 'react-native';
//recyclerview to fast performance
import { DataProvider, LayoutProvider, RecyclerListView } from 'recyclerlistview';

import Toolbar from '../components/Toolbar';
import SecureSelected from '../components/SecureSelected';
import Score from '../components/Score';
import SafeArea from '../components/SafeArea';

import Ionic from 'react-native-vector-icons/Ionicons';

import {
  DIAGONAL_SCREEN,
  DEVICE_HEIGHT,
  hp,
  IS_IPHONE_X,
  RF,
  STATUSBAR_HEIGHT,
  styles as dm,
  DEVICE_WIDTH,
  wp
} from '../utils/framework';

import consts from '../utils/consts';

import Shimmer from 'react-native-shimmer-placeholder';

//get height for recyclerview container
var SCROLLVIEW_HEIGHT = DEVICE_HEIGHT - 2 * consts.TOOLBAR_HEIGHT;
if (IS_IPHONE_X) SCROLLVIEW_HEIGHT += STATUSBAR_HEIGHT;

//Views DIMENSTIONS to improve performace
const AB_SIZE = DIAGONAL_SCREEN * 0.037;
const AB_RADIUS = AB_SIZE / 2;

//configutarion for recyclerview types
const ViewTypes = {
  USER_SCORE: 0,
  TRAVEL: 1
};

//height to each menu acoording its type
const USER_SCORE_HEIGHT = hp(5);
const TRAVEL_HEIGHT = DIAGONAL_SCREEN * 0.43;
const PADDING_TRAVEL = DIAGONAL_SCREEN * 0.01;

//DIMENSTIONS TO RESPONSIVE HEIGHT AND GOOD PERFORMANCE
const AB_LINE_HEIGHT = RF(3);
const AB_LINE_BLUE_WIDTH = wp(50);

export default class Travels extends React.Component {
  constructor(props) {
    super(props);
    //Create the data provider and provide method which takes in two rows of data and return if those two are different or not.
    //THIS IS VERY IMPORTANT, FORGET PERFORMANCE IF THIS IS MESSED UP
    this.dataProvider = new DataProvider((r1, r2) => {
      return r1 !== r2;
    });

    this._layoutProvider = new LayoutProvider(
      index => {
        switch (index) {
          case 0:
            return ViewTypes.USER_SCORE;
          default:
            return ViewTypes.TRAVEL;
        }
      },
      (type, dim) => {
        dim.width = DEVICE_WIDTH;
        dim.height = type === ViewTypes.USER_SCORE ? USER_SCORE_HEIGHT : TRAVEL_HEIGHT;
      }
    );

    this._rowRenderer = this._rowRenderer.bind(this);

    this.state = {
      travels: [], //travels
      dataProvider: this.dataProvider.cloneWithRows([]), //data to recyclerview
      isFetched: false //is true only if request has been success
    };
  }

  componentDidMount() {
    //test data  travels
    setTimeout(() => {
      var travels = [];
      for (var i = 0; i < 15; i++) {
        travels.push({ num: i });
      }
      this.setState({
        travels,
        dataProvider: this.dataProvider.cloneWithRows(travels),
        isFetched: true
      });
    }, 1000);
  }

  //Given type and data return the view component
  _rowRenderer(type, data) {
    switch (type) {
      case ViewTypes.USER_SCORE:
        return (
          <View
            style={{
              height: USER_SCORE_HEIGHT,
              backgroundColor: '#ececec',
              width: DEVICE_WIDTH,
              justifyContent: 'center'
            }}>
            <Text style={[dm.f_20, dm.pa_hor_20, dm.f_bold, dm.c_primary]}>OCTUBRE 2018</Text>

            {/* <View style={[dm.h_15p, dm.jc_c, dm.pa_hor_20, dm.w_100p]}>
                            <View style={[dm.flex_r, dm.ai_c]}>
                                <View style={{ backgroundColor: '#414548', borderRadius: 10 }}>
                                    <Text style={[dm.f_17, dm.c_white, dm.pa_hor_10]}>HOY</Text>
                                </View>
                                <Text style={[dm.f_15, dm.ma_l_10]}>15 de octubre de 2017</Text>
                            </View>


                            <View style={[dm.flex_r, dm.ai_c, dm.jc_sb, dm.ma_t_10]}>
                                <View style={[dm.center]}>
                                    <Text style={[dm.f_15, dm.pa_hor_10]}>Score</Text>
                                    <Text style={[dm.f_40, { color: consts.ORANGE, }]}>77</Text>
                                </View>

                                <View style={[dm.center]}>
                                    <Text style={[dm.f_15, dm.pa_hor_10]}>Puntos</Text>
                                    <Text style={[dm.f_40,]}>+50</Text>
                                </View>

                                <View style={[dm.center]}>
                                    <Text style={[dm.f_15, dm.pa_hor_10]}>Km recorridos</Text>
                                    <Text style={[dm.f_40]}>7.6</Text>
                                </View>

                                <View style={[dm.center]}>
                                    <Text style={[dm.f_15, dm.pa_hor_10]}>Km/h</Text>
                                    <Text style={[dm.f_40]}>23</Text>
                                </View>

                                <TouchableOpacity style={[dm.ma_l_10]}>
                                    <View style={[dm.center, { width: MORE_BUTTON_SIZE, height: MORE_BUTTON_SIZE, borderRadius: MORE_BUTTON_RADIUS, borderWidth: 1, borderColor: '#414548' }]}>
                                        <Image style={{ width: MORE_BUTTON_SIZE / 3, height: MORE_BUTTON_SIZE / 3 }} source={require('../icons/sum.png')} />
                                    </View>
                                </TouchableOpacity>

                            </View>


                        </View> */}
          </View>
        );

      case ViewTypes.TRAVEL:
        return (
          <View
            style={[
              dm.jc_sa,
              dm.b_white,
              {
                paddingTop: PADDING_TRAVEL,
                height: TRAVEL_HEIGHT - 4,
                borderBottomWidth: 4,
                borderBottomColor: '#ececec'
              }
            ]}>
            <View>
              {/** start travel number, score travel, kms, avg speed */}
              <Text style={[dm.f_20, dm.pa_hor_20, dm.ma_b_10]}>Lunes 12 nov. 2018</Text>
              {/** end travel number, score travel, kms, avg speed */}

              {/** start inicio-fin viaje */}
              <View style={[dm.flex_r, dm.center]}>
                <View
                  style={[
                    dm.b_primary,
                    dm.center,
                    { width: AB_SIZE, height: AB_SIZE, borderRadius: AB_RADIUS }
                  ]}>
                  <Text style={[dm.f_30, dm.c_white, { lineHeight: AB_LINE_HEIGHT }]}>A</Text>
                </View>

                <Text style={[dm.f_17, dm.ma_hor_5]}>18:05</Text>

                <View style={[dm.b_primary, { width: AB_LINE_BLUE_WIDTH, height: 2 }]} />

                <Text style={[dm.f_17, dm.ma_hor_5]}>18:57</Text>

                <View
                  style={[
                    dm.b_primary,
                    dm.center,
                    { width: AB_SIZE, height: AB_SIZE, borderRadius: AB_RADIUS }
                  ]}>
                  <Text style={[dm.f_30, dm.c_white, { lineHeight: AB_LINE_HEIGHT }]}>B</Text>
                </View>
              </View>

              <View style={[dm.flex_r, dm.ai_c, dm.jc_sb, dm.pa_hor_20, dm.ma_t_5]}>
                <Text numberOfLines={2} style={[dm.f_17, dm.w_30p]}>
                  Seguros{'\n'}Equinoccial
                </Text>
                <Text numberOfLines={2} style={[dm.f_17, dm.w_30p, dm.t_ar]}>
                  Av. 10 de Agosto{'\n'}y Fernando Vaca
                </Text>
              </View>
              {/** end inicio-fin viaje */}

              <View style={[dm.flex_r, { paddingTop: PADDING_TRAVEL }]}>
                <Score
                  topColor={consts.ORANGE}
                  topText={'15'}
                  topSmallText={'%'}
                  bottomText={`frenazos${'\n'}bruscos`}
                />
                <Score
                  topColor={consts.GREEN}
                  topText={'10'}
                  topSmallText={'%'}
                  bottomText={`exceso${'\n'}de velocidad`}
                  extraStyle={{
                    flex: 2,
                    borderColor: '#d2d2d2',
                    borderLeftWidth: 1,
                    borderRightWidth: 1
                  }}
                />
                <Score
                  topColor={consts.GREEN}
                  topText={'12'}
                  topSmallText={'%'}
                  bottomText={`aceleraciones${'\n'}bruscas`}
                />
              </View>

              <View style={[dm.flex_r, { paddingTop: PADDING_TRAVEL }]}>
                <Score
                  topColor={'#000'}
                  topText={20.5}
                  topSmallText={'km'}
                  bottomText={`distancia${'\n'}recorrida`}
                />
                <Score
                  topColor={consts.GREEN}
                  topText={80}
                  bottomText={`puntaje de${'\n'}conducción`}
                  extraStyle={{
                    flex: 2,
                    borderColor: '#d2d2d2',
                    borderLeftWidth: 1,
                    borderRightWidth: 1
                  }}
                />
                <Score
                  topColor={consts.GREEN}
                  topText={21}
                  topSmallText={'km/h'}
                  bottomText={`velocidad${'\n'}promedio`}
                />
              </View>
            </View>

            <View>
              {/** inico mapa */}
              {/* <TouchableOpacity onPress={() => this.props.navigation.navigate('travelDetail')}>
                            <View style={{
                                width: w,
                                height: hp(25),
                                marginTop: 10
                            }} pointerEvents="none">
                                <MapView
                                    style={[dm.fill]}
                                    provider={PROVIDER_GOOGLE}
                                    initialRegion={{
                                        latitude: -0.1846998,
                                        longitude: -78.4806459,
                                        latitudeDelta: 0.002,
                                        longitudeDelta: 0.002,
                                    }}
                                    cacheEnabled
                                    zoomEnabled={false}
                                    pitchEnabled={false}
                                    scrollingEnabled={false}
                                >
                                    <Marker
                                        coordinate={{
                                            latitude: -0.1846998,
                                            longitude: -78.4806459
                                        }}
                                        centerOffset={{ x: -18, y: -60 }}
                                        anchor={{ x: 0.69, y: 1 }}

                                    />
                                </MapView>
                            </View>
                        </TouchableOpacity>
                         */}
              {/** fin mapa */}

              {/** VER DETALLES Y MAPA */}
              <View style={[dm.flex_r, dm.pa_hor_15, dm.pa_ver_10]}>
                <TouchableOpacity
                  style={{ flex: 1 }}
                  onPress={() => this.props.navigation.navigate('travelDetail')}>
                  <View
                    style={{
                      backgroundColor: consts.PRIMARY,
                      borderRadius: 10
                    }}>
                    <Text style={[dm.f_18, dm.f_bold, dm.pa_ver_10, dm.t_ac, dm.c_white]}>
                      VER DETALLES Y MAPA
                    </Text>
                  </View>
                </TouchableOpacity>
              </View>
              {/** fin VER DETALLES Y MAPA */}
            </View>
          </View>
        );

      default:
        return null;
    }
  }

  render() {
    const { isFetched } = this.state;
    return (
      <SafeArea>
        <View style={[dm.flex_1, dm.b_white, { width: DEVICE_WIDTH }]}>
          {/** start Toolbar */}
          <Toolbar
            leftOnPress={() => this.props.navigation.goBack()}
            leftIcon={<Ionic name="ios-arrow-round-back" style={[dm.c_white, dm.f_40]} />}
          />
          {/** end Toolbar */}

          <SecureSelected />

          <View style={{ height: SCROLLVIEW_HEIGHT, width: DEVICE_WIDTH }}>
            <RecyclerListView
              ref={ref => (this.mlist = ref)}
              style={{ flex: 1 }}
              layoutProvider={this._layoutProvider}
              dataProvider={this.state.dataProvider}
              rowRenderer={this._rowRenderer}
            />

            {/**start shimmer */}
            {!isFetched && (
              <View style={[dm.fill, { backgroundColor: '#ececec' }]}>
                <View
                  style={{
                    backgroundColor: '#ececec',
                    width: DEVICE_WIDTH
                  }}>
                  <View style={[dm.h_5p, dm.jc_c, dm.pa_hor_20, dm.w_100p]}>
                    <View style={[dm.flex_r, dm.ai_c]}>
                      <Shimmer autoRun width={wp(30)} style={[dm.ma_l_10]} />
                    </View>
                  </View>
                </View>

                <View style={[dm.ma_b_10, dm.b_white]}>
                  <View style={[dm.flex_r, dm.ai_c, dm.jc_sb, dm.ma_t_10, dm.ma_hor_20]}>
                    <Shimmer autoRun width={190} height={20} />
                  </View>

                  <View style={[dm.flex_r, dm.ai_c, dm.jc_sb, dm.ma_t_10, dm.ma_hor_20]}>
                    <Shimmer autoRun width={50} height={40} />
                    <Shimmer autoRun width={wp(50)} height={10} />
                    <Shimmer autoRun width={50} height={40} />
                  </View>

                  <View style={[dm.flex_r, dm.ai_c, dm.jc_sb, dm.ma_t_10, dm.ma_hor_20]}>
                    <Shimmer autoRun width={100} height={40} />

                    <Shimmer autoRun width={100} height={40} />
                  </View>

                  <Shimmer autoRun width={DEVICE_WIDTH} height={hp(20)} style={dm.ma_t_15} />

                  <View style={[dm.flex_r, dm.ai_c, dm.jc_sb, dm.ma_ver_10, dm.ma_hor_15]}>
                    <Shimmer autoRun height={hp(5)} style={[dm.flex_1]} />
                  </View>
                </View>

                <View style={[dm.ma_b_10, dm.b_white]}>
                  <View style={[dm.flex_r, dm.ai_c, dm.jc_sb, dm.ma_t_10, dm.ma_hor_20]}>
                    <Shimmer autoRun width={190} height={20} />
                  </View>

                  <View style={[dm.flex_r, dm.ai_c, dm.jc_sb, dm.ma_t_10, dm.ma_hor_20]}>
                    <Shimmer autoRun width={50} height={40} />
                    <Shimmer autoRun width={wp(50)} height={10} />
                    <Shimmer autoRun width={50} height={40} />
                  </View>

                  <View style={[dm.flex_r, dm.ai_c, dm.jc_sb, dm.ma_t_10, dm.ma_hor_20]}>
                    <Shimmer autoRun width={100} height={40} />

                    <Shimmer autoRun width={100} height={40} />
                  </View>

                  <Shimmer autoRun width={DEVICE_WIDTH} height={hp(20)} style={dm.ma_t_15} />

                  <View style={[dm.flex_r, dm.ai_c, dm.jc_sb, dm.ma_ver_10, dm.ma_hor_15]}>
                    <Shimmer autoRun height={hp(5)} style={[dm.flex_1]} />
                  </View>
                </View>
              </View>
            )}
            {/**end shimmer */}
          </View>
        </View>
      </SafeArea>
    );
  }
}
