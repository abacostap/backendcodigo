export default {
  PRIMARY: '#003B74',
  SECONDARY: '#002b5a',
  GREEN: '#00be7c',
  RED: '#FF0000',
  ORANGE: '#FF7F00',
  PHONE_REPORT_SINISTER: '1800378466',
  TOOLBAR_HEIGHT: 55,
  BOTTOMBAR_HEIGHT: 60,
  API_HOST: 'https://your-mock-server.local',
  EQUISMART_IOS: 'https://itunes.apple.com/ec/app/equismart/id1021068245?mt=8',
  EQUISMART_ANDROID: 'https://play.google.com/store/apps/details?id=com.solmovsa.sesa.gui&hl=es'
};
const CRYPTO = 'silly-wavy-prior-gaur-spica-weedy-papa';
const EMPTY_ARRAY = [{}, {}]; //this is used by the recyclerview to show the user score (position 0) and travel text (position 1)]
export { EMPTY_ARRAY, CRYPTO };
