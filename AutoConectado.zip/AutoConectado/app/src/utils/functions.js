import { NavigationActions } from 'react-navigation';
import { Alert } from 'react-native';

import TouchID from 'react-native-touch-id';

export function GDouglasPeucker(source, kink) {
  /* source[] Input coordinates in google.maps.LatLngs    */
  /* kink in metres, kinks above this depth kept  */
  /* kink depth is the height of the triangle abc where a-b and b-c are two consecutive line segments */
  var n_source, n_stack, n_dest, start, end, i, sig;
  var dev_sqr, max_dev_sqr, band_sqr;
  var x12, y12, d12, x13, y13, d13, x23, y23, d23;
  var F = (Math.PI / 180.0) * 0.5;
  var index = [];
  /* aray of indexes of source points to include in the reduced line */
  var sig_start = [];
  /* indices of start & end of working section */
  var sig_end = [];

  /* check for simple cases */

  if (source.length < 3) return source;
  /* one or two points */

  /* more complex case. initialize stack */

  n_source = source.length;
  band_sqr = (kink * 360.0) / (2.0 * Math.PI * 6378137.0);
  /* Now in degrees */
  band_sqr *= band_sqr;
  n_dest = 0;
  sig_start[0] = 0;
  sig_end[0] = n_source - 1;
  n_stack = 1;

  /* while the stack is not empty  ... */
  while (n_stack > 0) {
    /* ... pop the top-most entries off the stacks */

    start = sig_start[n_stack - 1];
    end = sig_end[n_stack - 1];
    n_stack--;

    if (end - start > 1) {
      /* any intermediate points ? */

      /* ... yes, so find most deviant intermediate point to
             either side of line joining start & end points */

      x12 = source[end].longitude - source[start].longitude;
      y12 = source[end].latitude - source[start].latitude;
      if (Math.abs(x12) > 180.0) x12 = 360.0 - Math.abs(x12);
      x12 *= Math.cos(F * (source[end].latitude + source[start].latitude));
      /* use avg lat to reduce lng */
      d12 = x12 * x12 + y12 * y12;

      for (i = start + 1, sig = start, max_dev_sqr = -1.0; i < end; i++) {
        x13 = source[i].longitude - source[start].longitude;
        y13 = source[i].latitude - source[start].latitude;
        if (Math.abs(x13) > 180.0) x13 = 360.0 - Math.abs(x13);
        x13 *= Math.cos(F * (source[i].latitude + source[start].latitude));
        d13 = x13 * x13 + y13 * y13;

        x23 = source[i].longitude - source[end].longitude;
        y23 = source[i].latitude - source[end].latitude;
        if (Math.abs(x23) > 180.0) x23 = 360.0 - Math.abs(x23);
        x23 *= Math.cos(F * (source[i].latitude + source[end].latitude));
        d23 = x23 * x23 + y23 * y23;

        if (d13 >= d12 + d23) dev_sqr = d23;
        else if (d23 >= d12 + d13) dev_sqr = d13;
        else dev_sqr = ((x13 * y12 - y13 * x12) * (x13 * y12 - y13 * x12)) / d12; // solve triangle

        if (dev_sqr > max_dev_sqr) {
          sig = i;
          max_dev_sqr = dev_sqr;
        }
      }

      if (max_dev_sqr < band_sqr) {
        /* is there a sig. intermediate point ? */
        /* ... no, so transfer current start point */
        index[n_dest] = start;
        n_dest++;
      } else {
        /* ... yes, so push two sub-sections on stack for further processing */
        n_stack++;
        sig_start[n_stack - 1] = sig;
        sig_end[n_stack - 1] = end;
        n_stack++;
        sig_start[n_stack - 1] = start;
        sig_end[n_stack - 1] = sig;
      }
    } else {
      /* ... no intermediate points, so transfer current start point */
      index[n_dest] = start;
      n_dest++;
    }
  }

  /* transfer last point */
  index[n_dest] = n_source - 1;
  n_dest++;

  /* make return array */
  var r = [];
  for (var i = 0; i < n_dest; i++) r.push(source[index[i]]);
  return r;
}

//calcula la velocidad promedio
export function calcuateAVGSpeed(lastTimestamp, currenTimestamp, distance) {
  //d=v*dt ==> v= d/dt
  //dt=timestamp2-timestamp1
  var diff = lastTimestamp.valueOf() - currenTimestamp.valueOf();
  var dt = diff / 1000 / 60 / 60;
  return distance / dt;
}

export const isNullOrEmpty = function(str) {
  return !str || str == undefined || str == '' || str == 'null' || str.length == 0;
};

export function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
  var R = 6371; // Radius of the earth in km
  var dLat = deg2rad(lat2 - lat1); // deg2rad below
  var dLon = deg2rad(lon2 - lon1);
  var a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  var d = R * c; // Distance in km
  return d;
}

export function deg2rad(deg) {
  return deg * (Math.PI / 180);
}

export function kmToMeters(kms) {
  return kms * 1000;
}

Math.radians = function(degrees) {
  return (degrees * Math.PI) / 180;
};

// Converts from radians to degrees.
Math.degrees = function(radians) {
  return (radians * 180) / Math.PI;
};

/**
 * calculate bearing between two points
 * @param pointA
 * @param pointB
 * @returns {number} bearing
 */
export function getBearing(pointA, pointB) {
  const startLat = Math.radians(pointA.latitude);
  const startLong = Math.radians(pointA.longitude);
  const endLat = Math.radians(pointB.latitude);
  const endLong = Math.radians(pointB.longitude);

  let dLong = endLong - startLong;

  const dPhi = Math.log(
    Math.tan(endLat / 2.0 + Math.PI / 4.0) / Math.tan(startLat / 2.0 + Math.PI / 4.0)
  );

  if (Math.abs(dLong) > Math.PI) {
    if (dLong > 0) {
      dLong = -(2.0 * Math.PI - dLong);
    } else {
      dLong = 2.0 * Math.PI + dLong;
    }
  }

  return (Math.degrees(Math.atan2(dLong, dPhi)) + 360.0) % 360.0; //return bearing
}

export function dateToText(date) {
  var dd = date.getDate();
  var mm = date.getMonth() + 1; //January is 0!
  var yyyy = date.getFullYear();

  if (dd < 10) {
    dd = '0' + dd;
  }

  if (mm < 10) {
    mm = '0' + mm;
  }

  var months = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC'];

  return dd + '-' + months[mm - 1] + '-' + yyyy;
}

export function getDateInSpanish(date) {
  var days = ['Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sábado'];
  var months = [
    'enero',
    'febrero',
    'marzo',
    'abril',
    'mayo',
    'junio',
    'julio',
    'agosto',
    'septiembre',
    'octubre',
    'noviembre',
    'diciembre'
  ];

  var dd = date.getDate();
  var h = date.getHours();
  var m = date.getMinutes();
  var s = date.getSeconds();

  if (dd < 10) {
    dd = '0' + dd;
  }

  if (h < 10) {
    h = '0' + h;
  }

  if (m < 10) {
    m = '0' + m;
  }

  if (s < 10) {
    s = '0' + s;
  }
  return {
    dayName: days[date.getDay()],
    day: dd,
    month: date.getMonth() + 1, //January is 0!
    monthName: months[date.getMonth()],
    year: date.getFullYear(),
    hours: h,
    minutes: m,
    seconds: s
  };
}

/**
 * remove the current page from the pile (history) and show a new page
 * @param routeName string the page name to navigate
 * @param params object with the params
 */
export function goToWithoutHistory(props, routeName, params = {}) {
  const resetAction = NavigationActions.reset({
    index: 0,
    actions: [NavigationActions.navigate({ routeName, params })]
  });
  props.navigation.dispatch(resetAction); //navigate to home page
}

export async function validateTouchID(props) {
  try {
    //touchID configuration to Android and iOS
    const optionalConfigObject = {
      title: 'Autenticación Requerida', // Android
      imageColor: '#e00606', // Android
      imageErrorColor: '#ff0000', // Android
      sensorDescription: 'Sensor de huella dactilar', // Android
      sensorErrorDescription: 'Error en la lectura', // Android
      cancelText: 'Cancelar', // Android
      fallbackLabel: 'Mostrar código de acceso', // iOS (if empty, then label is hidden)
      unifiedErrors: false, // use unified error messages (default false)
      passcodeFallback: false // iOS
    };

    //get touchID result
    const isOK = await TouchID.authenticate(
      'Identifíquese para ingresar a su cuenta',
      optionalConfigObject
    );

    if (isOK === true) {
      return true;
    }
  } catch (error) {
    if (error.name) {
      switch (error.name) {
        case 'LAErrorPasscodeNotSet':
          props.appStore.setBiometric(null);
          Alert.alert(
            'ERROR',
            'La autenticación no pudo iniciarse porque NO tiene definida una contraseña en el dispositivo.'
          );
          break;
        case 'LAErrorTouchIDNotEnrolled':
          props.appStore.setBiometric(null);
          Alert.alert(
            'ERROR',
            'La autenticación no se pudo iniciar porque Touch ID no tiene huellas registradas.'
          );
          break;
        case 'RCTTouchIDNotSupported':
          props.appStore.setBiometric(null);
          Alert.alert(
            'ERROR',
            'El dispositivo no es compatible con Touch ID / Face ID  o no tiene permiso para acceder a ellos'
          );
          break;
        default:
          return false;
      }
    }

    return false;
  }
}
