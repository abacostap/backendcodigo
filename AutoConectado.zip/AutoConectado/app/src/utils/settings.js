import { CRYPTO } from '../utils/consts';
import { isNullOrEmpty } from './functions';
import { Alert, AsyncStorage, NativeModules, Platform } from 'react-native';
import CryptoJS from 'crypto-js';
import SInfo from 'react-native-sensitive-info';

const KEYS = {
  SAVED: 'SAVED',
  USER: 'USER',
  FINGERPRINT: 'FINGERPRINT',
  NOTIFICATION: 'NOTIFICATION'
};

function encrypt(data, isJSON = false) {
  return CryptoJS.AES.encrypt(isJSON ? JSON.stringify(data) : data, CRYPTO).toString();
}

function decrypt(encrypted, isJSON = false) {
  const decryptedData = CryptoJS.AES.decrypt(encrypted, CRYPTO).toString(CryptoJS.enc.Utf8);
  return isJSON ? JSON.parse(decryptedData) : decryptedData;
}

export async function setSetting(KEY, value, isJSON = false) {
  try {
    const encryptedSetting = encrypt(value, isJSON);
    await AsyncStorage.setItem(KEY, encryptedSetting);
    console.log('setting saved');
    return { status: 200 };
  } catch (error) {
    console.error('setting', error.message);
    throw new Error(error.message);
  }
}

export async function getSetting(KEY, isJSON = false) {
  try {
    const encrypted = await AsyncStorage.getItem(KEY);
    if (isNullOrEmpty(encrypted)) throw new Error('No data found');
    const decrypted = decrypt(encrypted, isJSON);
    return decrypted;
  } catch (error) {
    return null;
  }
}

export async function removeSetting(KEY) {
  try {
    await AsyncStorage.removeItem(KEY);
    return true;
  } catch (error) {
    return false;
  }
}

export async function logOut() {
  try {
    await AsyncStorage.removeItem(KEYS.SAVED);
    return { status: 200 };
  } catch (error) {
    throw new Error(error.message);
  }
}

/**
 * saves the user data into the sharedPreferences on android 23 or below
 * @param {Object} user
 */
export async function setUserAndroidBelow23(user) {
  try {
    const userEncrypted = encrypt(user, true);
    await AsyncStorage.setItem(KEYS.USER, userEncrypted);
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * gets the user data from the sharedPreferences on android 23 or below
 */
export async function getUserAndroidBelow23() {
  const encryptedUser = await AsyncStorage.getItem(KEYS.USER);

  if (isNullOrEmpty(encryptedUser)) throw new Error('usuario no encontrado');

  const decryptedUser = decrypt(encryptedUser, true);
  return decryptedUser;
}

/**
 * save the user data in a secure storage on iOS and  Android 23 or above
 * @param {object} options
 */
export async function setUserInSecureStorage(options) {
  if ((Platform.OS === 'android' && Platform.Version >= 23) || Platform.OS === 'ios') {
    return await storeUserAndroid23orIOS(options);
  } else {
    //for android versions below to API 23
    await setUserAndroidBelow23(options.data);
    return true;
  }
}

/**
 * get user from keychain or keystore
 * @param {boolean} touchID
 */
export async function getUserFromSecureStorage(touchID) {
  if ((Platform.OS === 'android' && Platform.Version >= 23) || Platform.OS === 'ios') {
    const value = await SInfo.getItem(KEYS.USER, {
      sharedPreferencesName: 'mySharedPrefs',
      keychainService: 'myKeychain',
      touchID: touchID,
      showModal: touchID,
      strings: {
        header: 'Autenticación Requerida',
        success: 'Usuario autentificado',
        hint: 'Detectando...',
        notRecognized: 'No se reconoce la huella',
        description: `Utiliza tu huella digital para  verificar tu identidad`,
        cancel: 'Cancelar',
        cancelled: 'Autenticación cancelada' // reject error message
      }
    });
    return JSON.parse(value);
  } else {
    //for android versions below to API 23

    return await getUserAndroidBelow23();
  }
}

/**
 * save the user data into a secure storage with or without touchID/FaceID
 * @param {object} options
 */
async function storeUserAndroid23orIOS(options) {
  try {
    if (options.touchID === true) {
      await SInfo.setItem(KEYS.USER, JSON.stringify(options.data), {
        keychainService: 'myKeychain',
        kSecAccessControl: 'kSecAccessControlTouchIDAny',
        sharedPreferencesName: 'mySharedPrefs',
        touchID: options.touchID || false,
        showModal: options.touchID || false,
        strings: {
          header: 'Autenticación Requerida',
          success: 'Usuario autentificado',
          hint: 'Detectando...',
          notRecognized: 'No se reconoce la huella',
          description: `Utiliza tu huella digital para  verificar tu identidad`,
          cancel: 'Cancelar',
          cancelled: 'Autenticación cancelada' // reject error message
        }
      });
    } else {
      throw new Error('save without touchID');
    }
    return true;
  } catch (error) {
    if (error.message == 'null') {
      if (options.touchID === true && Platform.OS == 'android') {
        NativeModules.CleanerAndroid.clearData();
      }
    }
    if (options.showError || false) {
      Alert.alert(
        'ERROR',
        'Ha ocurrido un error al verificar su identidad. Se ha guardado su información sin verificación por TouchID'
      );
    }
    await SInfo.setItem(KEYS.USER, JSON.stringify(options.data), {
      keychainService: 'myKeychain',
      sharedPreferencesName: 'mySharedPrefs'
    });

    return false;
  }
}

export { KEYS };
